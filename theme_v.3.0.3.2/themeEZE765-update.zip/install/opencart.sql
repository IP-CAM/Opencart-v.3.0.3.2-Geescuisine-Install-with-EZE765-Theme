
SET SQL_MODE = "";

--
-- Table structure for table `oc_banner`
--

CREATE TABLE IF NOT EXISTS `oc_banner` (
  `banner_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_banner`
--

INSERT INTO `oc_banner` (`banner_id`, `name`, `status`) VALUES
(17, 'Menu Banners', 1),
(19, 'banner_home', 1),
(27, 'Product Banner 1', 1),
(28, 'Product banner 2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oc_banner_image`
--

CREATE TABLE IF NOT EXISTS `oc_banner_image` (
  `banner_image_id` int(11) NOT NULL,
  `banner_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `title` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `link` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_banner_image`
--

INSERT INTO `oc_banner_image` (`banner_image_id`, `banner_id`, `language_id`, `title`, `description`, `link`, `image`, `sort_order`) VALUES
(1036, 19, 3, 'banner2', '												&lt;p class=&quot;h4&quot;&gt;Create your own pizza&lt;/p&gt;\r\n&lt;h3&gt;ONLY $9.99&lt;/h3&gt; \r\n					 \r\n					', 'index.php?route=product/category&amp;path=107', 'catalog/banners/banner-2.jpg', 2),
(1037, 19, 3, 'banner3', '												&lt;p class=&quot;h4&quot;&gt;Chicken Burgers&lt;/p&gt;\r\n&lt;h3&gt;Best price&lt;/h3&gt; \r\n					 \r\n					', 'index.php?route=product/category&amp;path=37', 'catalog/banners/banner-3.jpg', 3),
(1046, 17, 3, 'banner-bags-1', '																		&lt;p class=&quot;h6&quot;&gt;Deals!&lt;/p&gt;\r\n&lt;p class=&quot;h5&quot;&gt;On Featured Products&lt;/p&gt;\r\n&lt;h3&gt;Offer 70% Off&lt;/h3&gt;\r\n \r\n					 \r\n					 \r\n					', 'index.php?route=product/category&amp;path=92', 'catalog/banner4.jpg', 1),
(1045, 17, 2, 'banner-bags-1', '																		&lt;p class=&quot;h6&quot;&gt;Deals!&lt;/p&gt;\r\n&lt;p class=&quot;h5&quot;&gt;On Featured Products&lt;/p&gt;\r\n&lt;h3&gt;Offer 70% Off&lt;/h3&gt;\r\n \r\n					 \r\n					 \r\n					', 'index.php?route=product/category&amp;path=92', 'catalog/banner4.jpg', 1),
(1044, 17, 1, 'Menu Banner 1', '																		&lt;p class=&quot;h6&quot;&gt;Deals!&lt;/p&gt;\r\n&lt;p class=&quot;h5&quot;&gt;On Featured Products&lt;/p&gt;\r\n&lt;h3&gt;Offer 70% Off&lt;/h3&gt;\r\n \r\n					 \r\n					 \r\n					', 'index.php?route=product/category&amp;path=92', 'catalog/banner4.jpg', 1),
(1035, 19, 3, 'banner1', '												&lt;p class=&quot;h4&quot;&gt;Delicious Italian pasta&lt;/p&gt;\r\n&lt;h3&gt;Now 45 % Off&lt;/h3&gt; \r\n					 \r\n					', 'index.php?route=product/category&amp;path=106', 'catalog/banners/banner-1.jpg', 1),
(1032, 19, 2, 'banner1', '												&lt;p class=&quot;h4&quot;&gt;Delicious Italian pasta&lt;/p&gt;\r\n&lt;h3&gt;Now 45 % Off&lt;/h3&gt; \r\n					 \r\n					', 'index.php?route=product/category&amp;path=106', 'catalog/banners/banner-1.jpg', 1),
(1033, 19, 2, 'banner2', '												&lt;p class=&quot;h4&quot;&gt;Create your own pizza&lt;/p&gt;\r\n&lt;h3&gt;ONLY $9.99&lt;/h3&gt; \r\n					 \r\n					', 'index.php?route=product/category&amp;path=107', 'catalog/banners/banner-2.jpg', 2),
(1034, 19, 2, 'banner3', '												&lt;p class=&quot;h4&quot;&gt;Chicken Burgers&lt;/p&gt;\r\n&lt;h3&gt;Best price&lt;/h3&gt; \r\n					 \r\n					', 'index.php?route=product/category&amp;path=37', 'catalog/banners/banner-3.jpg', 3),
(1031, 19, 1, 'banner3', '												&lt;p class=&quot;h4&quot;&gt;Chicken Burgers&lt;/p&gt;\r\n&lt;h3&gt;Best price&lt;/h3&gt; \r\n					 \r\n					', 'index.php?route=product/category&amp;path=37', 'catalog/banners/banner-3.jpg', 3),
(1030, 19, 1, 'banner2', '												&lt;p class=&quot;h4&quot;&gt;Create your own pizza&lt;/p&gt;\r\n&lt;h3&gt;ONLY $9.99&lt;/h3&gt; \r\n					 \r\n					', 'index.php?route=product/category&amp;path=107', 'catalog/banners/banner-2.jpg', 2),
(1029, 19, 1, 'banner1', '												&lt;p class=&quot;h4&quot;&gt;Delicious Italian pasta&lt;/p&gt;\r\n&lt;h3&gt;Now 45 % Off&lt;/h3&gt; \r\n					 \r\n					', 'index.php?route=product/category&amp;path=106', 'catalog/banners/banner-1.jpg', 1),
(1040, 27, 3, 'product_banner', '																		&lt;h4&gt;Best Ever Burgers&lt;/h4&gt;\r\n&lt;p&gt;Tincidunt tristique augue fusce felis cursus sed porttitor.  &lt;/p&gt;\r\n&lt;span class=&quot;btn btn-lg btn-primary&quot;&gt;shop  -  $35.00 &lt;/span&gt; \r\n					 \r\n					 \r\n					 \r\n					', 'index.php?route=product/category&amp;path=25', 'catalog/product_banner1.jpg', 0),
(1041, 28, 1, 'product banner', '												&lt;h4&gt;Vegetarian Lunch&lt;/h4&gt;\r\n&lt;p&gt;Tincidunt tristique augue fusce felis cursus sed porttitor.  &lt;/p&gt;\r\n&lt;span class=&quot;btn btn-lg btn-primary&quot;&gt;shop  -  $30.00 &lt;/span&gt;  \r\n					 \r\n					', 'index.php?route=product/category&amp;path=34', 'catalog/product_banner2.jpg', 0),
(1043, 28, 3, 'product_banner', '												&lt;h4&gt;Vegetarian Lunch&lt;/h4&gt;\r\n&lt;p&gt;Tincidunt tristique augue fusce felis cursus sed porttitor.  &lt;/p&gt;\r\n&lt;span class=&quot;btn btn-lg btn-primary&quot;&gt;shop  -  $30.00 &lt;/span&gt;   \r\n					 \r\n					', 'index.php?route=product/category&amp;path=34', 'catalog/product_banner2.jpg', 0),
(1038, 27, 1, 'product banner', '																		&lt;h4&gt;Best Ever Burgers&lt;/h4&gt;\r\n&lt;p&gt;Tincidunt tristique augue fusce felis cursus sed porttitor.  &lt;/p&gt;\r\n&lt;span class=&quot;btn btn-lg btn-primary&quot;&gt;shop  -  $35.00 &lt;/span&gt; \r\n					 \r\n					 \r\n					 \r\n					', 'index.php?route=product/category&amp;path=25', 'catalog/product_banner1.jpg', 1),
(1039, 27, 2, 'product_banner', '																		&lt;h4&gt;Best Ever Burgers&lt;/h4&gt;\r\n&lt;p&gt;Tincidunt tristique augue fusce felis cursus sed porttitor.  &lt;/p&gt;\r\n&lt;span class=&quot;btn btn-lg btn-primary&quot;&gt;shop  -  $35.00 &lt;/span&gt;  \r\n					 \r\n					 \r\n					 \r\n					', 'index.php?route=product/category&amp;path=25', 'catalog/product_banner1.jpg', 0),
(1042, 28, 2, 'product_banner', '												&lt;h4&gt;Vegetarian Lunch&lt;/h4&gt;\r\n&lt;p&gt;Tincidunt tristique augue fusce felis cursus sed porttitor.  &lt;/p&gt;\r\n&lt;span class=&quot;btn btn-lg btn-primary&quot;&gt;shop  -  $30.00 &lt;/span&gt;  \r\n					 \r\n					', 'index.php?route=product/category&amp;path=34', 'catalog/product_banner2.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_layout`
--

CREATE TABLE IF NOT EXISTS `oc_layout` (
  `layout_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_layout`
--

INSERT INTO `oc_layout` (`layout_id`, `name`) VALUES
(1, 'Home'),
(2, 'Product'),
(3, 'Category'),
(4, 'Default'),
(16, 'Manufacturer'),
(6, 'Account'),
(7, 'Checkout'),
(8, 'Contact'),
(9, 'Sitemap'),
(10, 'Affiliate'),
(11, 'Information'),
(12, 'Compare'),
(13, 'Search'),
(14, 'Blog'),
(15, 'Specials'),
(17, 'Manufacturer info'),
(18, 'Bestseller');

-- --------------------------------------------------------

--
-- Table structure for table `oc_layout_module`
--

CREATE TABLE IF NOT EXISTS `oc_layout_module` (
  `layout_module_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL,
  `code` varchar(64) NOT NULL,
  `position` varchar(14) NOT NULL,
  `sort_order` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_layout_module`
--

INSERT INTO `oc_layout_module` (`layout_module_id`, `layout_id`, `code`, `position`, `sort_order`) VALUES
(1570, 10, 'zemez_newsletter_popup.99', 'footer_1', 2),
(1567, 6, 'zemez_layout_builder.148', 'footer_1', 1),
(1562, 12, 'zemez_newsletter_popup.99', 'footer_1', 0),
(1683, 4, 'zemez_layout_builder.129', 'header_top', 1),
(1605, 2, 'zemez_newsletter_popup.99', 'footer_1', 0),
(1606, 2, 'zemez_layout_builder.148', 'footer_1', 1),
(1579, 3, 'zemez_newsletter_popup.99', 'footer_1', 0),
(1575, 14, 'zemez_layout_builder.148', 'footer_1', 1),
(1580, 3, 'zemez_layout_builder.148', 'footer_1', 1),
(1584, 7, 'zemez_layout_builder.148', 'footer_1', 1),
(1597, 16, 'zemez_newsletter_popup.99', 'footer_1', 0),
(1598, 16, 'zemez_layout_builder.148', 'footer_1', 1),
(1566, 6, 'zemez_newsletter_popup.99', 'footer_1', 0),
(1565, 6, 'zemez_layout_builder.129', 'header_top', 1),
(1564, 6, 'zemez_layout_builder.58', 'header_top', 0),
(1569, 10, 'zemez_layout_builder.129', 'header_top', 1),
(1568, 10, 'zemez_layout_builder.58', 'header_top', 0),
(1574, 14, 'zemez_newsletter_popup.99', 'footer_1', 0),
(1573, 14, 'zemez_blog_category.143', 'column_left', 0),
(1572, 14, 'zemez_layout_builder.129', 'header_top', 1),
(1563, 12, 'zemez_layout_builder.148', 'footer_1', 1),
(1583, 7, 'zemez_newsletter_popup.99', 'footer_1', 0),
(1582, 7, 'zemez_layout_builder.129', 'header_top', 1),
(1581, 7, 'zemez_layout_builder.58', 'header_top', 0),
(1561, 12, 'zemez_layout_builder.129', 'header_top', 1),
(1560, 12, 'zemez_layout_builder.58', 'header_top', 0),
(1502, 8, 'zemez_newsletter_popup.99', 'footer_1', 2),
(1499, 8, 'zemez_google_map.47', 'content_top', 0),
(1682, 4, 'zemez_layout_builder.58', 'header_top', 0),
(1594, 11, 'zemez_layout_builder.148', 'footer_1', 1),
(1591, 11, 'zemez_layout_builder.58', 'header_top', 0),
(1592, 11, 'zemez_layout_builder.129', 'header_top', 1),
(1593, 11, 'zemez_newsletter_popup.99', 'footer_1', 0),
(1596, 16, 'zemez_layout_builder.129', 'header_top', 1),
(1595, 16, 'zemez_layout_builder.58', 'header_top', 0),
(1602, 17, 'zemez_layout_builder.148', 'footer_1', 1),
(1599, 17, 'zemez_layout_builder.58', 'header_top', 0),
(1600, 17, 'zemez_layout_builder.129', 'header_top', 1),
(1601, 17, 'zemez_newsletter_popup.99', 'footer_1', 0),
(1604, 2, 'zemez_layout_builder.129', 'header_top', 2),
(1603, 2, 'zemez_layout_builder.58', 'header_top', 0),
(1607, 13, 'zemez_layout_builder.58', 'header_top', 0),
(1608, 13, 'zemez_layout_builder.129', 'header_top', 1),
(1609, 13, 'zemez_newsletter_popup.99', 'footer_1', 0),
(1610, 13, 'zemez_layout_builder.148', 'footer_1', 1),
(1614, 9, 'zemez_layout_builder.148', 'footer_1', 1),
(1611, 9, 'zemez_layout_builder.58', 'header_top', 0),
(1612, 9, 'zemez_layout_builder.129', 'header_top', 1),
(1613, 9, 'zemez_newsletter_popup.99', 'footer_1', 0),
(1709, 15, 'zemez_layout_builder.148', 'footer_1', 1),
(1629, 1, 'zemez_layout_builder.109', 'content_top', 0),
(1630, 1, 'zemez_newsletter_popup.99', 'footer_1', 0),
(1498, 8, 'zemez_layout_builder.129', 'header_top', 1),
(1497, 8, 'zemez_layout_builder.58', 'header_top', 0),
(1571, 14, 'zemez_layout_builder.58', 'header_top', 0),
(1628, 1, 'zemez_layout_builder.133', 'top', 0),
(1627, 1, 'zemez_layout_builder.129', 'header_top', 1),
(1578, 3, 'filter', 'column_left', 2),
(1577, 3, 'zemez_layout_builder.129', 'header_top', 1),
(1576, 3, 'zemez_layout_builder.58', 'header_top', 0),
(1626, 1, 'zemez_layout_builder.58', 'header_top', 0),
(1631, 1, 'zemez_layout_builder.148', 'footer_1', 1),
(1708, 15, 'zemez_newsletter_popup.99', 'footer_1', 0),
(1724, 18, 'zemez_newsletter_popup.99', 'footer_1', 1),
(1722, 18, 'bestseller.50', 'content_top', 0),
(1723, 18, 'zemez_layout_builder.148', 'footer_1', 0),
(1721, 18, 'zemez_layout_builder.129', 'header_top', 1),
(1707, 15, 'zemez_layout_builder.129', 'header_top', 1),
(1706, 15, 'zemez_layout_builder.58', 'header_top', 0),
(1684, 4, 'zemez_newsletter_popup.99', 'footer_1', 0),
(1685, 4, 'zemez_layout_builder.148', 'footer_1', 1),
(1720, 18, 'zemez_layout_builder.58', 'header_top', 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_layout_route`
--

CREATE TABLE IF NOT EXISTS `oc_layout_route` (
  `layout_route_id` int(11) NOT NULL,
  `layout_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `route` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_layout_route`
--

INSERT INTO `oc_layout_route` (`layout_route_id`, `layout_id`, `store_id`, `route`) VALUES
(285, 6, 0, 'account/%'),
(286, 10, 0, 'affiliate/%'),
(288, 3, 0, 'product/category'),
(299, 1, 0, 'common/home'),
(294, 2, 0, 'product/product'),
(291, 11, 0, 'information/information'),
(289, 7, 0, 'checkout/%'),
(271, 8, 0, 'information/contact'),
(296, 9, 0, 'information/sitemap'),
(311, 4, 0, '/%'),
(284, 12, 0, 'product/compare'),
(295, 13, 0, 'product/search'),
(316, 15, 0, 'product/special'),
(292, 16, 0, 'product/manufacturer/info'),
(287, 14, 0, 'simple_blog/article'),
(293, 17, 0, 'product/manufacturer/info'),
(319, 18, 0, 'product/bestseller');

-- --------------------------------------------------------

--
-- Table structure for table `oc_module`
--

CREATE TABLE IF NOT EXISTS `oc_module` (
  `module_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `code` varchar(32) NOT NULL,
  `setting` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_module`
--

INSERT INTO `oc_module` (`module_id`, `name`, `code`, `setting`) VALUES
(148, 'Footer Main', 'zemez_layout_builder', '{"status":"1","name":"Footer Main","class":"order-lg","id":"","layout":"[{\\"index\\":0,\\"cls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"fullwidth\\":0,\\"parallax\\":0,\\"sfxcls\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"cols\\":[{\\"index\\":0,\\"cls\\":\\"\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":2,\\"mdcol\\":6,\\"smcol\\":6,\\"xscol\\":12,\\"widgets\\":[{\\"name\\":\\"Footer Links Information\\",\\"module\\":\\"zemez_footer_links.41\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]},{\\"index\\":0,\\"cls\\":\\"\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":2,\\"mdcol\\":6,\\"smcol\\":6,\\"xscol\\":12,\\"widgets\\":[{\\"name\\":\\"Footer Links My account\\",\\"module\\":\\"zemez_footer_links.42\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]},{\\"index\\":0,\\"cls\\":\\"text-center \\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":4,\\"mdcol\\":12,\\"smcol\\":12,\\"xscol\\":12,\\"widgets\\":[{\\"name\\":\\"Logo\\",\\"module\\":\\"zemez_logo.97\\",\\"tyle\\":\\"module\\"},{\\"name\\":\\"Home Nesletter\\",\\"module\\":\\"zemez_newsletter.161\\",\\"tyle\\":\\"module\\"},{\\"name\\":\\"Social List\\",\\"module\\":\\"zemez_social_list.44\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]},{\\"index\\":0,\\"cls\\":\\"\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":2,\\"mdcol\\":6,\\"smcol\\":6,\\"xscol\\":12,\\"widgets\\":[{\\"name\\":\\"Footer Links Ways\\",\\"module\\":\\"zemez_footer_links.63\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]},{\\"index\\":0,\\"cls\\":\\"\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":2,\\"mdcol\\":6,\\"smcol\\":6,\\"xscol\\":12,\\"widgets\\":[{\\"name\\":\\"Footer Links Contact us\\",\\"module\\":\\"zemez_footer_links.43\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]}]}]"}'),
(58, 'Header Top', 'zemez_layout_builder', '{"status":"1","name":"Header Top","class":"","id":"","layout":"[{\\"cls\\":\\"order-sm-1 items-center\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"fullwidth\\":\\"0\\",\\"sfxcls\\":null,\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":null,\\"iattachment\\":null,\\"cols\\":[{\\"index\\":0,\\"cls\\":\\"d-flex align-items-center left-position\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":4,\\"lgcol\\":4,\\"mdcol\\":4,\\"smcol\\":4,\\"xscol\\":6,\\"widgets\\":[{\\"name\\":\\"ZEMEZ Nav\\",\\"module\\":\\"zemez_nav\\",\\"tyle\\":\\"module\\"},{\\"name\\":\\"ZEMEZ Search\\",\\"module\\":\\"zemez_search\\",\\"tyle\\":\\"module\\"},{\\"name\\":\\"Permanent links\\",\\"module\\":\\"html.131\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]},{\\"index\\":0,\\"cls\\":\\"text-center order-lg-item\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":4,\\"mdcol\\":4,\\"smcol\\":4,\\"xscol\\":12,\\"widgets\\":[{\\"name\\":\\"Logo\\",\\"module\\":\\"zemez_logo.97\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]},{\\"index\\":0,\\"cls\\":\\"d-flex align-items-center right-position\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":4,\\"lgcol\\":4,\\"mdcol\\":4,\\"smcol\\":4,\\"xscol\\":6,\\"widgets\\":[{\\"name\\":\\"Custom text \\",\\"module\\":\\"html.132\\",\\"tyle\\":\\"module\\"},{\\"name\\":\\"ZEMEZ NavBlock\\",\\"module\\":\\"zemez_navblock\\",\\"tyle\\":\\"module\\"},{\\"name\\":\\"ZEMEZ Cart\\",\\"module\\":\\"zemez_cart\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]}]}]"}'),
(157, 'From the blog', 'zemez_blog_articles', '{"status":"1","name":"From the blog","layout_type":"1","article_limit":"4","show_readmore":"0","show_date":"1","show_author":"1","show_comments":"1","show_image":"1","image_width":"568","image_height":"568","show_description":"0","description_limit":"100","category_id":"popular"}'),
(154, 'Megamenu Top', 'zemez_megamenu', '{"name":"Megamenu Top","status":"1","menu_item":[{"type":"1","1":{"title":"Appetizers ","link":"index.php?route=product\\/category&amp;path=32"},"2":{"title":"Appetizers ","link":"index.php?route=product\\/category&amp;path=32"},"3":{"title":"Appetizers ","link":"index.php?route=product\\/category&amp;path=32"},"submenu_show":"1","submenu_type":"1","columns":"5","columns-per-row":"5","image":"","image_width":"1170","image_height":"600","column":[{"width":"13%","content":"4","limit":"5","prod_limit":"6","module_id":"135","category_id":"20","category_show":"1"},{"width":"13%","content":"4","limit":"5","prod_limit":"6","module_id":"135","category_id":"28","category_show":"1"},{"width":"13%","content":"4","limit":"5","prod_limit":"6","module_id":"135","category_id":"20","category_show":"1"},{"width":"20%","content":"0","limit":"4","prod_limit":"1","module_id":"159","category_id":"18","category_show":"1"},{"width":"41%","content":"0","limit":"0","prod_limit":"0","module_id":"83","category_id":"20","category_show":"1"}]},{"type":"1","1":{"title":"Soups","link":"index.php?route=product\\/category&amp;path=28"},"2":{"title":"Soups","link":"index.php?route=product\\/category&amp;path=28"},"3":{"title":"Soups","link":"index.php?route=product\\/category&amp;path=28"},"submenu_show":"0","submenu_type":"0","columns":"4","columns-per-row":"1","image":"","image_width":"","image_height":"","column":[{"width":"25%","content":"2","limit":"6","prod_limit":"6","module_id":"135","category_id":"20","category_show":"0"},{"width":"25%","content":"2","limit":"6","prod_limit":"0","module_id":"135","category_id":"20","category_show":"0"},{"width":"25%","content":"2","limit":"6","prod_limit":"0","module_id":"135","category_id":"20","category_show":"0"},{"width":"25%","content":"2","limit":"6","prod_limit":"0","module_id":"135","category_id":"20","category_show":"0"}]},{"type":"1","1":{"title":"Salads","link":"index.php?route=product\\/category&amp;path=25"},"2":{"title":"Salads","link":"index.php?route=product\\/category&amp;path=25"},"3":{"title":"Salads","link":"index.php?route=product\\/category&amp;path=25"},"submenu_show":"0","submenu_type":"0","columns":"1","columns-per-row":"1","image":"","image_width":"","image_height":"","column":[{"width":"100%","content":"0","limit":"7","prod_limit":"1","module_id":"83","category_id":"20","category_show":"0"}]},{"type":"1","1":{"title":"Pizza","link":"index.php?route=product\\/category&amp;path=18"},"2":{"title":"Pizza","link":"index.php?route=product\\/category&amp;path=18"},"3":{"title":"Pizza","link":"index.php?route=product\\/category&amp;path=18"},"submenu_show":"0","submenu_type":"0","columns":"0","columns-per-row":"0","image":"","image_width":"","image_height":""},{"type":"1","1":{"title":"Desserts","link":"index.php?route=product\\/category&amp;path=34"},"2":{"title":"Desserts","link":"index.php?route=product\\/category&amp;path=34"},"3":{"title":"Desserts","link":"index.php?route=product\\/category&amp;path=34"},"submenu_show":"0","submenu_type":"0","columns":"0","columns-per-row":"0","image":"","image_width":"","image_height":""}]}'),
(135, 'Banner home set', 'banner', '{"class":"banner_home_set","name":"Banner home set","banner_id":"19","width":"568","height":"568","status":"1"}'),
(47, 'Google Map', 'zemez_google_map', '{"name":"Google Map","zemez_google_map_key":"","status":"1","zemez_google_map_zoom":"14","zemez_google_map_type":"1","zemez_google_map_sensor":"true","zemez_google_map_width":"100%","zemez_google_map_height":"400px","zemez_google_map_styles":"                                                                [{&quot;featureType&quot;:&quot;administrative&quot;,&quot;elementType&quot;:&quot;labels.text.fill&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#444444&quot;}]},{&quot;featureType&quot;:&quot;landscape&quot;,&quot;elementType&quot;:&quot;all&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#f2f2f2&quot;}]},{&quot;featureType&quot;:&quot;poi&quot;,&quot;elementType&quot;:&quot;all&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;off&quot;}]},{&quot;featureType&quot;:&quot;road&quot;,&quot;elementType&quot;:&quot;all&quot;,&quot;stylers&quot;:[{&quot;saturation&quot;:-100},{&quot;lightness&quot;:45}]},{&quot;featureType&quot;:&quot;road.highway&quot;,&quot;elementType&quot;:&quot;all&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;simplified&quot;}]},{&quot;featureType&quot;:&quot;road.arterial&quot;,&quot;elementType&quot;:&quot;labels.icon&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;off&quot;}]},{&quot;featureType&quot;:&quot;transit&quot;,&quot;elementType&quot;:&quot;all&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;off&quot;}]},{&quot;featureType&quot;:&quot;water&quot;,&quot;elementType&quot;:&quot;all&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#46bcec&quot;},{&quot;visibility&quot;:&quot;on&quot;}]}]                                                        ","zemez_google_map_disable_ui":"false","zemez_google_map_scrollwheel":"false","zemez_google_map_draggable":"true","zemez_google_map_marker":"catalog\\/marker_map.png","zemez_google_map_marker_active":"catalog\\/marker_map_active.png","zemez_google_map_marker_width":"40","zemez_google_map_marker_height":"40"}'),
(143, 'Blog Category', 'zemez_blog_category', '{"status":"1","name":"Blog Category","category_search_article":"1"}'),
(138, 'Special Home', 'special', '{"name":"Special Home","product_timers":"1","layout_type":"1","limit":"8","width":"387","height":"387","status":"1"}'),
(97, 'Logo', 'zemez_logo', '{"name":"Logo","width":"270","height":"94","status":"1"}'),
(41, 'Footer Links Information', 'zemez_footer_links', '{"name":"Footer Links Information","type":"0","status":"1"}'),
(42, 'Footer Links My account', 'zemez_footer_links', '{"name":"Footer Links My account","type":"1","status":"1"}'),
(43, 'Footer Links Contact us', 'zemez_footer_links', '{"name":"Footer Links Contact us","type":"2","status":"1"}'),
(44, 'Social List', 'zemez_social_list', '{"name":"Social List","status":"1","title":{"1":"Get connected","2":"Get connected","3":"\\u0627\\u0644\\u062d\\u0635\\u0648\\u0644 \\u0639\\u0644\\u0649 \\u0627\\u062a\\u0635\\u0627\\u0644"},"description":{"1":"Like, share, or follow for exclusive info! ","2":"Like, share, or follow for exclusive info! ","3":"\\u0645\\u062b\\u0644\\u060c \\u062d\\u0635\\u0629\\u060c \\u0623\\u0648 \\u0645\\u062a\\u0627\\u0628\\u0639\\u0629 \\u0644\\u0645\\u0632\\u064a\\u062f \\u0645\\u0646 \\u0627\\u0644\\u0645\\u0639\\u0644\\u0648\\u0645\\u0627\\u062a \\u0627\\u0644\\u062d\\u0635\\u0631\\u064a\\u0629!"},"socials":{"1":{"1":{"name":"Google+","link":"\\/\\/plus.google.com\\/+TemplateMonster","css":"fa fa-google-plus"},"2":{"name":"Rss","link":"\\/\\/en.wikipedia.org\\/wiki\\/RSS","css":"fa fa-rss"},"3":{"name":"Pinterest","link":"\\/\\/www.pinterest.com\\/templatemonster\\/","css":"fa fa-pinterest"},"5":{"name":"Twitter","link":"\\/\\/twitter.com\\/zemezlab","css":"fa fa-twitter"},"6":{"name":"Facebook","link":"\\/\\/www.facebook.com\\/zemezlab\\/","css":"fa fa-facebook"}},"2":{"1":{"name":"Google+","link":"\\/\\/plus.google.com\\/+TemplateMonster","css":"fa fa-google-plus"},"2":{"name":"Rss","link":"\\/\\/en.wikipedia.org\\/wiki\\/RSS","css":"fa fa-rss"},"3":{"name":"Pinterest","link":"\\/\\/www.pinterest.com\\/templatemonster\\/","css":"fa fa-pinterest"},"5":{"name":"Twitter","link":"\\/\\/twitter.com\\/zemezlab","css":"fa fa-twitter"},"6":{"name":"Facebook","link":"\\/\\/www.facebook.com\\/zemezlab\\/","css":"fa fa-facebook"}},"3":{"1":{"name":"Google+","link":"\\/\\/plus.google.com\\/+TemplateMonster","css":"fa fa-google-plus"},"2":{"name":"Rss","link":"\\/\\/en.wikipedia.org\\/wiki\\/RSS","css":"fa fa-rss"},"3":{"name":"Pinterest","link":"\\/\\/www.pinterest.com\\/templatemonster\\/","css":"fa fa-pinterest"},"5":{"name":"Twitter","link":"\\/\\/twitter.com\\/zemezlab","css":"fa fa-twitter"},"6":{"name":"Facebook","link":"\\/\\/www.facebook.com\\/zemezlab\\/","css":"fa fa-facebook"}}}}'),
(50, 'Bestsellers Home', 'bestseller', '{"name":"Bestsellers Home","layout_type":"0","limit":"6","width":"387","height":"387","status":"1"}'),
(160, 'Featured products', 'zemez_single_category_product', '{"name":"Featured products","path":"Featured products","category":"0","tabs":"0","layout_type":"0","type":"3","special":"0","bestseller":"0","latest":"0","featured":"0","product":["34","42","43","35","47","49","46","50"],"limit":"8","width":"387","height":"387","status":"1"}'),
(63, 'Footer Links Ways', 'zemez_footer_links', '{"name":"Footer Links Ways","type":"3","status":"1"}'),
(70, 'About our store', 'html', '{"name":"About our store","class":"html-0","module_description":{"1":{"title":"About our store","description":"&lt;p&gt;We have a perfect reputation and great experience inthe fashion sphere and that is why our products are so popular and have many faithful fans all over the country. What we sell are not just simple handbags and clothes; the products of our shop are the part of a style . We know how important it is for the modern women to have several interesting and trendy goods. &lt;\\/p&gt;"},"2":{"title":"About our store","description":"&lt;p&gt;We have a perfect reputation and great experience inthe fashion sphere and that is why our products are so popular and have many faithful fans all over the country. What we sell are not just simple handbags and clothes; the products of our shop are the part of a style . We know how important it is for the modern women to have several interesting and trendy goods. &lt;\\/p&gt;"},"3":{"title":"\\u062d\\u0648\\u0644 \\u0645\\u062a\\u062c\\u0631 \\u0644\\u062f\\u064a\\u0646\\u0627","description":"&lt;p&gt;\\u0644\\u062f\\u064a\\u0646\\u0627 \\u0633\\u0645\\u0639\\u0629 \\u0645\\u0645\\u062a\\u0627\\u0632\\u0629 \\u0648\\u062a\\u062c\\u0631\\u0628\\u0629 \\u0631\\u0627\\u0626\\u0639\\u0629 \\u062a\\u064a \\u0625\\u062a\\u0634 \\u0645\\u062c\\u0627\\u0644 \\u0627\\u0644\\u0623\\u0632\\u064a\\u0627\\u0621 \\u0648\\u0647\\u0630\\u0627 \\u0647\\u0648 \\u0627\\u0644\\u0633\\u0628\\u0628 \\u0641\\u064a \\u0645\\u0646\\u062a\\u062c\\u0627\\u062a\\u0646\\u0627 \\u0647\\u064a \\u0634\\u0639\\u0628\\u064a\\u0629 \\u062c\\u062f\\u0627 \\u0648\\u0644\\u0647\\u0627 \\u0627\\u0644\\u0639\\u062f\\u064a\\u062f \\u0645\\u0646 \\u0627\\u0644\\u0645\\u0634\\u062c\\u0639\\u064a\\u0646 \\u0627\\u0644\\u0645\\u062e\\u0644\\u0635\\u064a\\u0646 \\u0641\\u064a \\u062c\\u0645\\u064a\\u0639 \\u0623\\u0646\\u062d\\u0627\\u0621 \\u0627\\u0644\\u0628\\u0644\\u0627\\u062f. \\u0645\\u0627 \\u0646\\u0628\\u064a\\u0639 \\u0644\\u064a\\u0633\\u062a \\u0645\\u062c\\u0631\\u062f \\u062d\\u0642\\u0627\\u0626\\u0628 \\u0628\\u0633\\u064a\\u0637\\u0629 \\u0648\\u0627\\u0644\\u0645\\u0644\\u0627\\u0628\\u0633. \\u0627\\u0644\\u0645\\u0646\\u062a\\u062c\\u0627\\u062a \\u0645\\u0646 \\u0645\\u062a\\u062c\\u0631 \\u0644\\u062f\\u064a\\u0646\\u0627 \\u0647\\u064a \\u062c\\u0632\\u0621 \\u0645\\u0646 \\u0646\\u0645\\u0637. \\u0648\\u0646\\u062d\\u0646 \\u0646\\u0639\\u0644\\u0645 \\u0643\\u0645 \\u0647\\u0648 \\u0645\\u0647\\u0645 \\u0628\\u0627\\u0644\\u0646\\u0633\\u0628\\u0629 \\u0644\\u0644\\u0646\\u0633\\u0627\\u0621 \\u0627\\u0644\\u062d\\u062f\\u064a\\u062b\\u0629 \\u0644\\u062f\\u064a\\u0647\\u0645 \\u0639\\u062f\\u0629 \\u0628\\u0636\\u0627\\u0626\\u0639 \\u0645\\u062b\\u064a\\u0631\\u0629 \\u0644\\u0644\\u0627\\u0647\\u062a\\u0645\\u0627\\u0645 \\u0648\\u0627\\u0644\\u0639\\u0635\\u0631\\u064a\\u0629.&lt;\\/p&gt;"}},"status":"1"}'),
(140, 'Bestsellers Home HTML ', 'html', '{"name":"Bestsellers Home HTML ","class":"bestsellers-home-html","module_description":{"1":{"title":"","description":"&lt;h4&gt;Discover the magic!&lt;\\/h4&gt;\\r\\n&lt;h2 class=&quot;h2 products-section-title&quot;&gt;Bestsellers&lt;\\/h2&gt;\\r\\n&lt;p&gt;100% authentic products, quick delivery, fast online support, and free gifts almost with every order. We also offer worldwide shipping of Korean cosmetics at affordable rates that depend on the weight of the package. If you are not satisfied with your purchase, you can return it to receive a full refund or store credit.&lt;\\/p&gt;"},"2":{"title":"","description":"&lt;h4&gt;Discover the magic!&lt;\\/h4&gt;\\r\\n&lt;h2 class=&quot;h2 products-section-title&quot;&gt;Bestsellers&lt;\\/h2&gt;\\r\\n&lt;p&gt;100% authentic products, quick delivery, fast online support, and free gifts almost with every order. We also offer worldwide shipping of Korean cosmetics at affordable rates that depend on the weight of the package. If you are not satisfied with your purchase, you can return it to receive a full refund or store credit.&lt;\\/p&gt;"},"3":{"title":"","description":"&lt;h4&gt;Discover the magic!&lt;\\/h4&gt;\\r\\n&lt;h2 class=&quot;h2 products-section-title&quot;&gt;Bestsellers&lt;\\/h2&gt;\\r\\n&lt;p&gt;100% authentic products, quick delivery, fast online support, and free gifts almost with every order. We also offer worldwide shipping of Korean cosmetics at affordable rates that depend on the weight of the package. If you are not satisfied with your purchase, you can return it to receive a full refund or store credit.&lt;\\/p&gt;"}},"status":"1"}'),
(83, 'Banners Top Menu', 'banner', '{"class":"banner_top_menu","name":"Banners Top Menu","banner_id":"17","width":"568","height":"568","status":"1"}'),
(86, 'Latest Home', 'latest', '{"name":"Latest Home","layout_type":"1","limit":"6","width":"387","height":"387","status":"1"}'),
(95, 'Slideshow', 'zemez_slideshow', '{"name":"Slideshow","status":"1","width":"1197","height":"890","min_height":"300","effect":"0","speed":"1200","autoplay":"0","keyboard_control":"0","mousewheel_control":"0","mousewheel_release_on_edges":"0","next_button":"0","prev_button":"0","pagination":"1","pagination_clickable":"1","pagination_bullet_render":"0","scrollbar":"0","scrollbar_draggable":"0","loop":"0","slides":[{"slide_type":"0","video_loop":"1","video_autoplay":"1","video_playback_rate":"1","video_muted":"0","video_volume":".2","image":"catalog\\/slide-1.jpg","title":{"1":"slide-1","2":"slide-1","3":"slide-1"},"description":{"1":"&lt;p class=&quot;h6&quot;&gt;Satisfaction Guarantee&lt;\\/p&gt;\\r\\n&lt;p class=&quot;h1&quot;&gt;The place &lt;br&gt;\\r\\nfor tasty food&lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Our store is more than just another average online retailer. We sell &lt;br&gt; not only top quality products, but give our customers a positive &lt;br&gt; online shopping experience.&lt;\\/p&gt;\\r\\n&lt;p class=&quot;btn btn-primary btn-lg&quot;&gt;Shop&lt;\\/p&gt;","2":"&lt;p class=&quot;h6&quot;&gt;Satisfaction Guarantee&lt;\\/p&gt;\\r\\n&lt;p class=&quot;h1&quot;&gt;The place &lt;br&gt;\\r\\nfor tasty food&lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Our store is more than just another average online retailer. We sell &lt;br&gt; not only top quality products, but give our customers a positive &lt;br&gt; online shopping experience.&lt;\\/p&gt;\\r\\n&lt;p class=&quot;btn btn-primary btn-lg&quot;&gt;Shop&lt;\\/p&gt;","3":"&lt;p class=&quot;h6&quot;&gt;Satisfaction Guarantee&lt;\\/p&gt;\\r\\n&lt;p class=&quot;h1&quot;&gt;The place &lt;br&gt;\\r\\nfor tasty food&lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Our store is more than just another average online retailer. We sell &lt;br&gt; not only top quality products, but give our customers a positive &lt;br&gt; online shopping experience.&lt;\\/p&gt;\\r\\n&lt;p class=&quot;btn btn-primary btn-lg&quot;&gt;Shop&lt;\\/p&gt;"},"link":"index.php?route=product\\/category&amp;path=18"},{"slide_type":"0","video_loop":"1","video_autoplay":"1","video_playback_rate":"1","video_muted":"0","video_volume":"0.2","image":"catalog\\/slide-2.jpg","title":{"1":"slide-2","2":"slide-2","3":"slide-2"},"description":{"1":"&lt;p class=&quot;h6&quot;&gt;Satisfaction Guarantee&lt;\\/p&gt;\\r\\n&lt;p class=&quot;h1&quot;&gt;The place &lt;br&gt;\\r\\nfor tasty food&lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Our store is more than just another average online retailer. We sell &lt;br&gt; not only top quality products, but give our customers a positive &lt;br&gt; online shopping experience.&lt;\\/p&gt;\\r\\n&lt;p class=&quot;btn btn-primary btn-lg&quot;&gt;Shop&lt;\\/p&gt;","2":"&lt;p class=&quot;h6&quot;&gt;Satisfaction Guarantee&lt;\\/p&gt;\\r\\n&lt;p class=&quot;h1&quot;&gt;The place &lt;br&gt;\\r\\nfor tasty food&lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Our store is more than just another average online retailer. We sell &lt;br&gt; not only top quality products, but give our customers a positive &lt;br&gt; online shopping experience.&lt;\\/p&gt;\\r\\n&lt;p class=&quot;btn btn-primary btn-lg&quot;&gt;Shop&lt;\\/p&gt;","3":"&lt;p class=&quot;h6&quot;&gt;Satisfaction Guarantee&lt;\\/p&gt;\\r\\n&lt;p class=&quot;h1&quot;&gt;The place &lt;br&gt;\\r\\nfor tasty food&lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Our store is more than just another average online retailer. We sell &lt;br&gt; not only top quality products, but give our customers a positive &lt;br&gt; online shopping experience.&lt;\\/p&gt;\\r\\n&lt;p class=&quot;btn btn-primary btn-lg&quot;&gt;Shop&lt;\\/p&gt;"},"link":"index.php?route=product\\/category&amp;path=34"},{"slide_type":"0","video_loop":"0","video_autoplay":"0","video_playback_rate":"0.2","video_muted":"1","video_volume":"","image":"catalog\\/slide-3.jpg","title":{"1":"slide-3","2":"slide-3","3":"slide-3"},"description":{"1":"&lt;p class=&quot;h6&quot;&gt;Satisfaction Guarantee&lt;\\/p&gt;\\r\\n&lt;p class=&quot;h1&quot;&gt;The place &lt;br&gt;\\r\\nfor tasty food&lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Our store is more than just another average online retailer. We sell &lt;br&gt; not only top quality products, but give our customers a positive &lt;br&gt; online shopping experience.&lt;\\/p&gt;\\r\\n&lt;p class=&quot;btn btn-primary btn-lg&quot;&gt;Shop&lt;\\/p&gt;","2":"&lt;p class=&quot;h6&quot;&gt;Satisfaction Guarantee&lt;\\/p&gt;\\r\\n&lt;p class=&quot;h1&quot;&gt;The place &lt;br&gt;\\r\\nfor tasty food&lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Our store is more than just another average online retailer. We sell &lt;br&gt; not only top quality products, but give our customers a positive &lt;br&gt; online shopping experience.&lt;\\/p&gt;\\r\\n&lt;p class=&quot;btn btn-primary btn-lg&quot;&gt;Shop&lt;\\/p&gt;","3":"&lt;p class=&quot;h6&quot;&gt;Satisfaction Guarantee&lt;\\/p&gt;\\r\\n&lt;p class=&quot;h1&quot;&gt;The place &lt;br&gt;\\r\\nfor tasty food&lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Our store is more than just another average online retailer. We sell &lt;br&gt; not only top quality products, but give our customers a positive &lt;br&gt; online shopping experience.&lt;\\/p&gt;\\r\\n&lt;p class=&quot;btn btn-primary btn-lg&quot;&gt;Shop&lt;\\/p&gt;"},"link":"index.php?route=product\\/category&amp;path=29"}]}'),
(99, 'Popup', 'zemez_newsletter_popup', '{"name":"Popup","newsletter_popup_bg":"catalog\\/banner4.jpg","newsletter_popup_bg_width":"454","newsletter_popup_bg_height":"623","newsletter_popup_cookie":"0","zemez_newsletter_popup_description":{"1":{"title":"Newsletter","description":"Subscribe to the Foodleco mailing list to receive updates on new arrivals, special offers and other discount information."},"2":{"title":"\\u041d\\u043e\\u0432\\u043e\\u0441\\u0442\\u043d\\u0430\\u044f \\u0440\\u0430\\u0441\\u0441\\u044b\\u043b\\u043a\\u0430","description":"\\u041f\\u043e\\u0434\\u043f\\u0438\\u0448\\u0438\\u0442\\u0435\\u0441\\u044c \\u043d\\u0430 \\u0441\\u043f\\u0438\\u0441\\u043e\\u043a \\u0440\\u0430\\u0441\\u0441\\u044b\\u043b\\u043a\\u0438 the Foodleco, \\u0447\\u0442\\u043e\\u0431\\u044b \\u043f\\u043e\\u043b\\u0443\\u0447\\u0430\\u0442\\u044c \\u043e\\u0431\\u043d\\u043e\\u0432\\u043b\\u0435\\u043d\\u0438\\u044f \\u043e \\u043d\\u043e\\u0432\\u044b\\u0445 \\u043f\\u043e\\u0441\\u0442\\u0443\\u043f\\u043b\\u0435\\u043d\\u0438\\u044f\\u0445, \\u0441\\u043f\\u0435\\u0446\\u0438\\u0430\\u043b\\u044c\\u043d\\u044b\\u0445 \\u043f\\u0440\\u0435\\u0434\\u043b\\u043e\\u0436\\u0435\\u043d\\u0438\\u044f\\u0445 \\u0438 \\u0434\\u0440\\u0443\\u0433\\u043e\\u0439 \\u0438\\u043d\\u0444\\u043e\\u0440\\u043c\\u0430\\u0446\\u0438\\u0438 \\u043e \\u0441\\u043a\\u0438\\u0434\\u043a\\u0430\\u0445."},"3":{"title":"\\u0627\\u0644\\u0646\\u0634\\u0631\\u0629 \\u0627\\u0644\\u0625\\u062e\\u0628\\u0627\\u0631\\u064a\\u0629","description":"\\u0627\\u0634\\u062a\\u0631\\u0643 \\u0641\\u064a \\u0627\\u0644\\u0642\\u0627\\u0626\\u0645\\u0629 \\u0627\\u0644\\u0628\\u0631\\u064a\\u062f\\u064a\\u0629 Foodleco \\u0644\\u062a\\u0644\\u0642\\u064a \\u0627\\u0644\\u062a\\u062d\\u062f\\u064a\\u062b\\u0627\\u062a \\u0639\\u0644\\u0649 \\u0627\\u0644\\u0648\\u0627\\u0641\\u062f\\u064a\\u0646 \\u0627\\u0644\\u062c\\u062f\\u062f\\u060c \\u0648\\u0627\\u0644\\u0639\\u0631\\u0648\\u0636 \\u0627\\u0644\\u062e\\u0627\\u0635\\u0629 \\u0648\\u0645\\u0639\\u0644\\u0648\\u0645\\u0627\\u062a \\u0627\\u0644\\u062e\\u0635\\u0645 \\u0627\\u0644\\u0623\\u062e\\u0631\\u0649."}},"status":"1"}'),
(137, 'Featured Home', 'featured', '{"name":"Featured Home","layout_type":"1","product_name":"","product":["61","208","201","200","206"],"limit":"5","width":"387","height":"387","status":"1"}'),
(159, 'Product Menu', 'zemez_single_category_product', '{"name":"Product Menu","path":"Bakery","category":"28","tabs":"0","layout_type":"0","type":"3","special":"0","bestseller":"0","latest":"0","featured":"0","product":["42"],"limit":"1","width":"200","height":"200","status":"1"}'),
(146, 'Custom  Bestseller Text', 'html', '{"name":"Custom  Bestseller Text","class":"custom-bestseller-text ","module_description":{"1":{"title":"","description":"&lt;p&gt;&lt;span&gt;Fresh, Fast, Delicious&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n&lt;p class=&quot;h4&quot;&gt;Best prices&lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Risus amet proin duis amet. Tempor, nunc quis a in &lt;br&gt; est ullamcorper mauris, quis etiam. Est urna, in &lt;br&gt; nunc in tellus vitae. &lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Tincidunt tristique augue fusce felis cursus sed &lt;br&gt; porttitor. Nunc nibh dui aliquet tortor dolor.  &lt;\\/p&gt;"},"2":{"title":"","description":"&lt;p&gt;&lt;span&gt;Fresh, Fast, Delicious&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n&lt;p class=&quot;h4&quot;&gt;Best prices&lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Risus amet proin duis amet. Tempor, nunc quis a in &lt;br&gt; est ullamcorper mauris, quis etiam. Est urna, in &lt;br&gt; nunc in tellus vitae. &lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Tincidunt tristique augue fusce felis cursus sed &lt;br&gt; porttitor. Nunc nibh dui aliquet tortor dolor.  &lt;\\/p&gt;"},"3":{"title":"","description":"&lt;p&gt;&lt;span&gt;Fresh, Fast, Delicious&lt;\\/span&gt;&lt;\\/p&gt;\\r\\n&lt;p class=&quot;h4&quot;&gt;Best prices&lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Risus amet proin duis amet. Tempor, nunc quis a in &lt;br&gt; est ullamcorper mauris, quis etiam. Est urna, in &lt;br&gt; nunc in tellus vitae. &lt;\\/p&gt;\\r\\n&lt;p class=&quot;text&quot;&gt;Tincidunt tristique augue fusce felis cursus sed &lt;br&gt; porttitor. Nunc nibh dui aliquet tortor dolor.  &lt;\\/p&gt;"}},"status":"1"}'),
(161, 'Home Newsletter', 'zemez_newsletter', '{"name":"Home Newsletter","status":"1","zemez_newsletter_description":{"1":{"description":"Subscribe to Newsletter"},"2":{"description":"Subscribe to Newsletter"},"3":{"description":"&lt;p&gt;&lt;span style=&quot;color: rgb(34, 34, 34); font-family: Consolas, &amp;quot;Lucida Console&amp;quot;, &amp;quot;Courier New&amp;quot;, monospace; font-size: 12px; white-space: pre-wrap;&quot;&gt;Subscribe to Newsletter&lt;\\/span&gt;&lt;br&gt;&lt;\\/p&gt;"}}}'),
(109, 'Home Main', 'zemez_layout_builder', '{"status":"1","name":"Home Main","class":"","id":"","layout":"[{\\"index\\":0,\\"cls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"fullwidth\\":0,\\"parallax\\":0,\\"sfxcls\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"cols\\":[{\\"index\\":0,\\"cls\\":\\"row\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":12,\\"mdcol\\":12,\\"smcol\\":12,\\"xscol\\":12,\\"widgets\\":[{\\"name\\":\\"Banner home set\\",\\"module\\":\\"banner.135\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]}]},{\\"index\\":0,\\"cls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"fullwidth\\":0,\\"parallax\\":0,\\"sfxcls\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"cols\\":[{\\"index\\":0,\\"cls\\":\\"\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":12,\\"mdcol\\":12,\\"smcol\\":12,\\"xscol\\":12,\\"widgets\\":[{\\"name\\":\\"Featured products\\",\\"module\\":\\"zemez_single_category_product.160\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]}]},{\\"cls\\":\\"custom-align  custom-multi-image\\",\\"bgcolor\\":\\"#F3F3F3\\",\\"bgimage\\":\\"\\",\\"fullwidth\\":\\"0\\",\\"sfxcls\\":null,\\"padding\\":\\"180px 0 320px\\",\\"margin\\":\\"\\",\\"iposition\\":null,\\"iattachment\\":null,\\"cols\\":[{\\"index\\":0,\\"cls\\":\\"\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":4,\\"mdcol\\":4,\\"smcol\\":12,\\"xscol\\":12,\\"widgets\\":[{\\"name\\":\\"Custom  Bestseller Text\\",\\"module\\":\\"html.146\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]},{\\"index\\":0,\\"cls\\":\\"\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":4,\\"mdcol\\":4,\\"smcol\\":6,\\"xscol\\":12,\\"widgets\\":[{\\"name\\":\\"Product banner\\",\\"module\\":\\"banner.162\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]},{\\"index\\":0,\\"cls\\":\\"\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":4,\\"mdcol\\":4,\\"smcol\\":6,\\"xscol\\":12,\\"widgets\\":[{\\"name\\":\\"Product banner\\",\\"module\\":\\"banner.163\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]}]},{\\"index\\":0,\\"cls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"fullwidth\\":0,\\"parallax\\":0,\\"sfxcls\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"cols\\":[{\\"index\\":0,\\"cls\\":\\"\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":12,\\"mdcol\\":12,\\"smcol\\":12,\\"xscol\\":12,\\"widgets\\":[{\\"name\\":\\"From the blog\\",\\"module\\":\\"zemez_blog_articles.157\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]}]}]"}'),
(164, 'Text with image', 'html', '{"name":"Text with image","class":"text_with_image","module_description":{"1":{"title":"","description":"&lt;div class=&quot;offset-md-1 col-sm-5 col-12&quot;&gt;\\r\\n  &lt;h3&gt;Hair extensions! &lt;br&gt;\\r\\nAdd volume &lt;br&gt; in seconds!&lt;\\/h3&gt;\\r\\n  &lt;p class=&quot;text&quot;&gt;Looking for a new flat iron, hair dryer, curling &lt;br&gt; iron or hair setter?&lt;\\/p&gt;\\t\\r\\n  &lt;p&gt;&lt;a class=&quot;btn btn-secondary&quot; href=&quot;index.php?route=product\\/category&amp;amp;path=30&quot;&gt;Shop&lt;\\/a&gt;&lt;\\/p&gt;\\r\\n&lt;\\/div&gt;\\r\\n&lt;div class=&quot;col-sm-6 pr-0 col-12&quot;&gt;\\r\\n &lt;p&gt;&lt;img src=&quot;image\\/catalog\\/banner4.jpg&quot; style=&quot;width: 872px;&quot;&gt;&lt;br&gt;&lt;\\/p&gt;\\r\\n&lt;\\/div&gt;"},"2":{"title":"","description":"&lt;div class=&quot;offset-md-1 col-sm-5 col-12&quot;&gt;\\r\\n  &lt;h3&gt;Hair extensions! &lt;br&gt;\\r\\nAdd volume &lt;br&gt; in seconds!&lt;\\/h3&gt;\\r\\n  &lt;p class=&quot;text&quot;&gt;Looking for a new flat iron, hair dryer, curling &lt;br&gt; iron or hair setter?&lt;\\/p&gt;\\t\\r\\n  &lt;p&gt;&lt;a class=&quot;btn btn-secondary&quot; href=&quot;index.php?route=product\\/category&amp;amp;path=30&quot;&gt;Shop&lt;\\/a&gt;&lt;\\/p&gt;\\r\\n&lt;\\/div&gt;\\r\\n&lt;div class=&quot;col-sm-6 pr-0 col-12&quot;&gt;\\r\\n &lt;p&gt;&lt;img src=&quot;image\\/catalog\\/banner4.jpg&quot; style=&quot;width: 872px;&quot;&gt;&lt;br&gt;&lt;\\/p&gt;\\r\\n&lt;\\/div&gt;"},"3":{"title":"","description":"&lt;div class=&quot;offset-md-1 col-sm-5 col-12&quot;&gt;\\r\\n  &lt;h3&gt;Hair extensions! &lt;br&gt;\\r\\nAdd volume &lt;br&gt; in seconds!&lt;\\/h3&gt;\\r\\n  &lt;p class=&quot;text&quot;&gt;Looking for a new flat iron, hair dryer, curling &lt;br&gt; iron or hair setter?&lt;\\/p&gt;\\t\\r\\n  &lt;p&gt;&lt;a class=&quot;btn btn-secondary&quot; href=&quot;index.php?route=product\\/category&amp;amp;path=30&quot;&gt;Shop&lt;\\/a&gt;&lt;\\/p&gt;\\r\\n&lt;\\/div&gt;\\r\\n&lt;div class=&quot;col-sm-6 pr-0 col-12&quot;&gt;\\r\\n &lt;p&gt;&lt;img src=&quot;image\\/catalog\\/banner4.jpg&quot; style=&quot;width: 872px;&quot;&gt;&lt;br&gt;&lt;\\/p&gt;\\r\\n&lt;\\/div&gt;"}},"status":"1"}'),
(133, 'Home Top', 'zemez_layout_builder', '{"status":"1","name":"Home Top","class":"","id":"","layout":"[{\\"cls\\":\\"\\",\\"bgcolor\\":\\"#fff\\",\\"bgimage\\":\\"\\",\\"fullwidth\\":\\"1\\",\\"sfxcls\\":null,\\"padding\\":\\"0 0 0 0\\",\\"margin\\":\\"\\",\\"iposition\\":\\"50% 50%\\",\\"iattachment\\":\\"fixed\\",\\"cols\\":[{\\"index\\":0,\\"cls\\":\\"\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":12,\\"mdcol\\":12,\\"smcol\\":12,\\"xscol\\":12,\\"widgets\\":[{\\"name\\":\\"Slideshow\\",\\"module\\":\\"zemez_slideshow.95\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]}]}]"}'),
(129, 'Header Menu', 'zemez_layout_builder', '{"status":"1","name":"Header Menu","class":"","id":"","layout":"[{\\"cls\\":\\"items-center mt-md-5 custom_position\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"fullwidth\\":\\"0\\",\\"sfxcls\\":null,\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":null,\\"iattachment\\":null,\\"cols\\":[{\\"index\\":0,\\"cls\\":\\"position_stat\\",\\"sfxcls\\":\\"\\",\\"bgcolor\\":\\"\\",\\"bgimage\\":\\"\\",\\"padding\\":\\"\\",\\"margin\\":\\"\\",\\"iposition\\":\\"\\",\\"iattachment\\":\\"\\",\\"inrow\\":0,\\"xlcol\\":12,\\"mdcol\\":12,\\"smcol\\":12,\\"xscol\\":12,\\"widgets\\":[{\\"name\\":\\"Megamenu Top\\",\\"module\\":\\"zemez_megamenu.154\\",\\"tyle\\":\\"module\\"}],\\"rows\\":[]}]}]"}'),
(132, 'Custom text ', 'html', '{"name":"Custom text ","class":"custom-text d-xl-block d-none","module_description":{"1":{"title":"","description":"&lt;p&gt;free shipping&amp;nbsp; &lt;em&gt;on all orders over $35*&lt;\\/em&gt;&lt;\\/p&gt;"},"2":{"title":"","description":"&lt;p&gt;free shipping&amp;nbsp; &lt;em&gt;on all orders over $35*&lt;\\/em&gt;&lt;\\/p&gt;"},"3":{"title":"","description":"&lt;p&gt;free shipping&amp;nbsp; &lt;em&gt;on all orders over $35*&lt;\\/em&gt;&lt;\\/p&gt;"}},"status":"1"}'),
(131, 'Permanent links', 'html', '{"name":"Permanent links","class":"permanent-links d-xl-block d-none","module_description":{"1":{"title":"","description":"&lt;ul&gt;\\r\\n\\t&lt;li&gt;&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=5&quot;&gt;Helps&lt;\\/a&gt;&lt;\\/li&gt;\\r\\n\\t&lt;li&gt;&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=6&quot;&gt;Shipping&lt;\\/a&gt;&lt;\\/li&gt;\\r\\n\\t&lt;li&gt;&lt;a href=&quot;index.php?route=information\\/contact&quot;&gt;Contacts&lt;\\/a&gt;&lt;\\/li&gt;\\r\\n&lt;\\/ul&gt;"},"2":{"title":"","description":"&lt;ul&gt;\\r\\n\\t&lt;li&gt;&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=5&quot;&gt;Helps&lt;\\/a&gt;&lt;\\/li&gt;\\r\\n\\t&lt;li&gt;&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=6&quot;&gt;Shipping&lt;\\/a&gt;&lt;\\/li&gt;\\r\\n\\t&lt;li&gt;&lt;a href=&quot;index.php?route=information\\/contact&quot;&gt;Contacts&lt;\\/a&gt;&lt;\\/li&gt;\\r\\n&lt;\\/ul&gt;"},"3":{"title":"","description":"&lt;ul&gt;\\r\\n\\t&lt;li&gt;&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=5&quot;&gt;Helps&lt;\\/a&gt;&lt;\\/li&gt;\\r\\n\\t&lt;li&gt;&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=6&quot;&gt;Shipping&lt;\\/a&gt;&lt;\\/li&gt;\\r\\n\\t&lt;li&gt;&lt;a href=&quot;index.php?route=information\\/contact&quot;&gt;Contacts&lt;\\/a&gt;&lt;\\/li&gt;\\r\\n&lt;\\/ul&gt;"}},"status":"1"}'),
(162, 'Product banner', 'banner', '{"class":"product_banner","name":"Product banner","banner_id":"27","width":"568","height":"452","status":"1"}'),
(163, 'Product banner', 'banner', '{"class":"product_banner","name":"Product banner","banner_id":"28","width":"568","height":"452","status":"1"}');

-- --------------------------------------------------------

--
-- Table structure for table `oc_setting`
--

CREATE TABLE IF NOT EXISTS `oc_setting` (
  `setting_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `code` varchar(128) NOT NULL,
  `key` varchar(128) NOT NULL,
  `value` text NOT NULL,
  `serialized` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_setting`
--

INSERT INTO `oc_setting` (`setting_id`, `store_id`, `code`, `key`, `value`, `serialized`) VALUES
(4, 0, 'voucher', 'total_voucher_sort_order', '8', 0),
(5, 0, 'voucher', 'total_voucher_status', '1', 0),
(8231, 0, 'payment_cod', 'payment_cod_total', '1', 0),
(8232, 0, 'payment_cod', 'payment_cod_order_status_id', '7', 0),
(8239, 0, 'payment_free_checkout', 'payment_free_checkout_sort_order', '1', 0),
(8238, 0, 'payment_free_checkout', 'payment_free_checkout_status', '1', 0),
(8234, 0, 'payment_cod', 'payment_cod_status', '1', 0),
(8233, 0, 'payment_cod', 'payment_cod_geo_zone_id', '0', 0),
(103, 0, 'shipping_flat', 'shipping_flat_sort_order', '1', 0),
(104, 0, 'shipping_flat', 'shipping_flat_status', '1', 0),
(105, 0, 'shipping_flat', 'shipping_flat_geo_zone_id', '0', 0),
(106, 0, 'shipping_flat', 'shipping_flat_tax_class_id', '9', 0),
(107, 0, 'shipping_flat', 'shipping_flat_cost', '5.00', 0),
(108, 0, 'total_shipping', 'total_shipping_sort_order', '3', 0),
(109, 0, 'total_sub_total', 'sub_total_sort_order', '1', 0),
(110, 0, 'total_sub_total', 'total_sub_total_status', '1', 0),
(111, 0, 'total_tax', 'total_tax_status', '1', 0),
(112, 0, 'total_total', 'total_total_sort_order', '9', 0),
(113, 0, 'total_total', 'total_total_status', '1', 0),
(114, 0, 'total_tax', 'total_tax_sort_order', '5', 0),
(115, 0, 'total_credit', 'total_credit_sort_order', '7', 0),
(116, 0, 'total_credit', 'total_credit_status', '1', 0),
(117, 0, 'total_reward', 'total_reward_sort_order', '2', 0),
(118, 0, 'total_reward', 'total_reward_status', '1', 0),
(119, 0, 'total_shipping', 'total_shipping_status', '1', 0),
(120, 0, 'total_shipping', 'total_shipping_estimator', '1', 0),
(121, 0, 'total_coupon', 'total_coupon_sort_order', '4', 0),
(122, 0, 'total_coupon', 'total_coupon_status', '1', 0),
(149, 0, 'dashboard_activity', 'dashboard_activity_status', '1', 0),
(150, 0, 'dashboard_activity', 'dashboard_activity_sort_order', '7', 0),
(151, 0, 'dashboard_sale', 'dashboard_sale_status', '1', 0),
(152, 0, 'dashboard_sale', 'dashboard_sale_width', '3', 0),
(153, 0, 'dashboard_chart', 'dashboard_chart_status', '1', 0),
(154, 0, 'dashboard_chart', 'dashboard_chart_width', '6', 0),
(155, 0, 'dashboard_customer', 'dashboard_customer_status', '1', 0),
(156, 0, 'dashboard_customer', 'dashboard_customer_width', '3', 0),
(157, 0, 'dashboard_map', 'dashboard_map_status', '1', 0),
(158, 0, 'dashboard_map', 'dashboard_map_width', '6', 0),
(159, 0, 'dashboard_online', 'dashboard_online_status', '1', 0),
(160, 0, 'dashboard_online', 'dashboard_online_width', '3', 0),
(161, 0, 'dashboard_order', 'dashboard_order_sort_order', '1', 0),
(162, 0, 'dashboard_order', 'dashboard_order_status', '1', 0),
(163, 0, 'dashboard_order', 'dashboard_order_width', '3', 0),
(164, 0, 'dashboard_sale', 'dashboard_sale_sort_order', '2', 0),
(165, 0, 'dashboard_customer', 'dashboard_customer_sort_order', '3', 0),
(166, 0, 'dashboard_online', 'dashboard_online_sort_order', '4', 0),
(167, 0, 'dashboard_map', 'dashboard_map_sort_order', '5', 0),
(168, 0, 'dashboard_chart', 'dashboard_chart_sort_order', '6', 0),
(169, 0, 'dashboard_recent', 'dashboard_recent_status', '1', 0),
(170, 0, 'dashboard_recent', 'dashboard_recent_sort_order', '8', 0),
(171, 0, 'dashboard_activity', 'dashboard_activity_width', '4', 0),
(172, 0, 'dashboard_recent', 'dashboard_recent_width', '8', 0),
(173, 0, 'report_customer_activity', 'report_customer_activity_status', '1', 0),
(174, 0, 'report_customer_activity', 'report_customer_activity_sort_order', '1', 0),
(175, 0, 'report_customer_order', 'report_customer_order_status', '1', 0),
(176, 0, 'report_customer_order', 'report_customer_order_sort_order', '2', 0),
(177, 0, 'report_customer_reward', 'report_customer_reward_status', '1', 0),
(178, 0, 'report_customer_reward', 'report_customer_reward_sort_order', '3', 0),
(179, 0, 'report_customer_search', 'report_customer_search_sort_order', '3', 0),
(180, 0, 'report_customer_search', 'report_customer_search_status', '1', 0),
(181, 0, 'report_customer_transaction', 'report_customer_transaction_status', '1', 0),
(182, 0, 'report_customer_transaction', 'report_customer_transaction_status_sort_order', '4', 0),
(183, 0, 'report_sale_tax', 'report_sale_tax_status', '1', 0),
(184, 0, 'report_sale_tax', 'report_sale_tax_sort_order', '5', 0),
(185, 0, 'report_sale_shipping', 'report_sale_shipping_status', '1', 0),
(186, 0, 'report_sale_shipping', 'report_sale_shipping_sort_order', '6', 0),
(187, 0, 'report_sale_return', 'report_sale_return_status', '1', 0),
(188, 0, 'report_sale_return', 'report_sale_return_sort_order', '7', 0),
(189, 0, 'report_sale_order', 'report_sale_order_status', '1', 0),
(190, 0, 'report_sale_order', 'report_sale_order_sort_order', '8', 0),
(191, 0, 'report_sale_coupon', 'report_sale_coupon_status', '1', 0),
(192, 0, 'report_sale_coupon', 'report_sale_coupon_sort_order', '9', 0),
(193, 0, 'report_product_viewed', 'report_product_viewed_status', '1', 0),
(194, 0, 'report_product_viewed', 'report_product_viewed_sort_order', '10', 0),
(195, 0, 'report_product_purchased', 'report_product_purchased_status', '1', 0),
(196, 0, 'report_product_purchased', 'report_product_purchased_sort_order', '11', 0),
(197, 0, 'report_marketing', 'report_marketing_status', '1', 0),
(198, 0, 'report_marketing', 'report_marketing_sort_order', '12', 0),
(5622, 0, 'developer', 'developer_sass', '1', 0),
(9318, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_location_height', '50', 0),
(9317, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_location_width', '268', 0),
(9315, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_cart_width', '72', 0),
(7879, 0, 'module_filter', 'module_filter_status', '1', 0),
(9316, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_cart_height', '72', 0),
(9313, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_wishlist_width', '120', 0),
(9314, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_wishlist_height', '120', 0),
(9312, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_compare_height', '120', 0),
(3834, 0, 'zemez_nav', 'zemez_nav_status', '1', 0),
(3835, 0, 'zemez_language', 'zemez_language_status', '1', 0),
(3836, 0, 'zemez_currency', 'zemez_currency_status', '1', 0),
(3845, 0, 'zemez_cart', 'zemez_cart_status', '1', 0),
(3840, 0, 'zemez_search', 'zemez_search_status', '1', 0),
(3846, 0, 'module_zemez_cart', 'module_zemez_cart_status', '1', 0),
(3847, 0, 'module_zemez_currency', 'module_zemez_currency_status', '1', 0),
(3848, 0, 'module_zemez_language', 'module_zemez_language_status', '1', 0),
(7878, 0, 'module_zemez_search', 'module_zemez_search_status', '1', 0),
(5433, 0, 'module_zemez_nav', 'module_zemez_nav_status', '1', 0),
(3945, 0, 'module_account', 'module_account_status', '1', 0),
(5621, 0, 'developer', 'developer_theme', '0', 0),
(9927, 0, 'config', 'config_compression', '0', 0),
(9311, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_compare_width', '120', 0),
(9928, 0, 'config', 'config_secure', '0', 0),
(9929, 0, 'config', 'config_password', '1', 0),
(9930, 0, 'config', 'config_shared', '0', 0),
(9931, 0, 'config', 'config_encryption', 'Pvj9NwQ26y6LiQXalx8MsxRsesWcfd2GeOI2akD6SNFV80Dt7go5sV9S6mRqNnhtpFsgJ17UwHr7XjiGpKSqzcvpauOhe87HAtZPHGmw2zOlzZvgkc1vGFvQiGESbRvFGjMgTIjtigUqUEWYO2K5dpLa55kFFogDFW8jYOWdgim2L8KF0hFt6DqX9lVaDFoxxCTVIaulJqTDSrBUjf39Nyml1VqndHgbcgY9I8Q9gNrMFWnmmvAlm841lQhzz0gtWHU6RXxPFHWpWcqVaRxDL9qN67FGlS26c2eHFtn7l6AFUcfzmB5XKvNNjxyNzjYzn9BoeJmMzjuEP39UXSUgNjMkRnZS3f0Bs31rxcN4jRT3r8Wj7P7tmf39IqPjhT4pQzUPWddrlOc3qh5YkZhVcHHEUkqWVqIUJ1aD34e0JxUnzU5IBGcoX40BTa98FfvycQeTw6VHCBgqPA04tsj9SWeaQxTfNIOEjEiEvd8haelYBBPoTZchI0ZmXyE1U11BorE6HYppQVcbb8kstOsy7u6U94XY4ubqcVUGNZrGsWrqh5giyFQTkXK7R2L9zFWml9iOWVezkyRLjZsq4uO0cxQ7V38TV8z1V16lqQ5Si3W4tGrGVSWQzZun8QwwmPdEUHrcrefakTQRV19Hw2wVuhNUIExBF0UPs8YicgoiUY0q2A9B9HPwE6SWeqPN48Jp7w8RaZqdZXegRc0xymqP3LeTtHSm9v0JONY9d2QWMcf3ZhORUrcaglVTZRogSF8NPitJGxlGpvanogB1r7hjnsLL8N4GTLb2F9SKP1z8LaP6lgVsVh3lBT8bSy5GVwgI9cbJYbKfBsrBBMEMTgPUKjH7ll1Mfp8UrTMWTYt7R0hwbnH0wCmfpjnH54qdfsDD7Zp8B5SVG0rh9Zm8VQUqZyN544mDPlZsQWP9JMEnpVCX3OnczyfdCgReox6zpLrnCBZ4HS2tIE1WYhgOOQpd6mUgmuZUDR0JQeFEevhteCtL9bzusWfeUzU8nNlihfqw', 0),
(9937, 0, 'config', 'config_error_filename', 'error.log', 0),
(9936, 0, 'config', 'config_error_log', '1', 0),
(9932, 0, 'config', 'config_file_max_size', '300000', 0),
(9933, 0, 'config', 'config_file_ext_allowed', 'zip\r\ntxt\r\npng\r\njpe\r\njpeg\r\njpg\r\ngif\r\nbmp\r\nico\r\ntiff\r\ntif\r\nsvg\r\nsvgz\r\nzip\r\nrar\r\nmsi\r\ncab\r\nmp3\r\nqt\r\nmov\r\npdf\r\npsd\r\nai\r\neps\r\nps\r\ndoc', 0),
(9934, 0, 'config', 'config_file_mime_allowed', 'text/plain\r\nimage/png\r\nimage/jpeg\r\nimage/gif\r\nimage/bmp\r\nimage/tiff\r\nimage/svg+xml\r\napplication/zip\r\n&quot;application/zip&quot;\r\napplication/x-zip\r\n&quot;application/x-zip&quot;\r\napplication/x-zip-compressed\r\n&quot;application/x-zip-compressed&quot;\r\napplication/rar\r\n&quot;application/rar&quot;\r\napplication/x-rar\r\n&quot;application/x-rar&quot;\r\napplication/x-rar-compressed\r\n&quot;application/x-rar-compressed&quot;\r\napplication/octet-stream\r\n&quot;application/octet-stream&quot;\r\naudio/mpeg\r\nvideo/quicktime\r\napplication/pdf', 0),
(9935, 0, 'config', 'config_error_display', '1', 0),
(5434, 0, 'module_zemez_navblock', 'module_zemez_navblock_status', '1', 0),
(9925, 0, 'config', 'config_seo_url', '0', 0),
(9926, 0, 'config', 'config_robots', 'abot\r\ndbot\r\nebot\r\nhbot\r\nkbot\r\nlbot\r\nmbot\r\nnbot\r\nobot\r\npbot\r\nrbot\r\nsbot\r\ntbot\r\nvbot\r\nybot\r\nzbot\r\nbot.\r\nbot/\r\n_bot\r\n.bot\r\n/bot\r\n-bot\r\n:bot\r\n(bot\r\ncrawl\r\nslurp\r\nspider\r\nseek\r\naccoona\r\nacoon\r\nadressendeutschland\r\nah-ha.com\r\nahoy\r\naltavista\r\nananzi\r\nanthill\r\nappie\r\narachnophilia\r\narale\r\naraneo\r\naranha\r\narchitext\r\naretha\r\narks\r\nasterias\r\natlocal\r\natn\r\natomz\r\naugurfind\r\nbackrub\r\nbannana_bot\r\nbaypup\r\nbdfetch\r\nbig brother\r\nbiglotron\r\nbjaaland\r\nblackwidow\r\nblaiz\r\nblog\r\nblo.\r\nbloodhound\r\nboitho\r\nbooch\r\nbradley\r\nbutterfly\r\ncalif\r\ncassandra\r\nccubee\r\ncfetch\r\ncharlotte\r\nchurl\r\ncienciaficcion\r\ncmc\r\ncollective\r\ncomagent\r\ncombine\r\ncomputingsite\r\ncsci\r\ncurl\r\ncusco\r\ndaumoa\r\ndeepindex\r\ndelorie\r\ndepspid\r\ndeweb\r\ndie blinde kuh\r\ndigger\r\nditto\r\ndmoz\r\ndocomo\r\ndownload express\r\ndtaagent\r\ndwcp\r\nebiness\r\nebingbong\r\ne-collector\r\nejupiter\r\nemacs-w3 search engine\r\nesther\r\nevliya celebi\r\nezresult\r\nfalcon\r\nfelix ide\r\nferret\r\nfetchrover\r\nfido\r\nfindlinks\r\nfireball\r\nfish search\r\nfouineur\r\nfunnelweb\r\ngazz\r\ngcreep\r\ngenieknows\r\ngetterroboplus\r\ngeturl\r\nglx\r\ngoforit\r\ngolem\r\ngrabber\r\ngrapnel\r\ngralon\r\ngriffon\r\ngromit\r\ngrub\r\ngulliver\r\nhamahakki\r\nharvest\r\nhavindex\r\nhelix\r\nheritrix\r\nhku www octopus\r\nhomerweb\r\nhtdig\r\nhtml index\r\nhtml_analyzer\r\nhtmlgobble\r\nhubater\r\nhyper-decontextualizer\r\nia_archiver\r\nibm_planetwide\r\nichiro\r\niconsurf\r\niltrovatore\r\nimage.kapsi.net\r\nimagelock\r\nincywincy\r\nindexer\r\ninfobee\r\ninformant\r\ningrid\r\ninktomisearch.com\r\ninspector web\r\nintelliagent\r\ninternet shinchakubin\r\nip3000\r\niron33\r\nisraeli-search\r\nivia\r\njack\r\njakarta\r\njavabee\r\njetbot\r\njumpstation\r\nkatipo\r\nkdd-explorer\r\nkilroy\r\nknowledge\r\nkototoi\r\nkretrieve\r\nlabelgrabber\r\nlachesis\r\nlarbin\r\nlegs\r\nlibwww\r\nlinkalarm\r\nlink validator\r\nlinkscan\r\nlockon\r\nlwp\r\nlycos\r\nmagpie\r\nmantraagent\r\nmapoftheinternet\r\nmarvin/\r\nmattie\r\nmediafox\r\nmediapartners\r\nmercator\r\nmerzscope\r\nmicrosoft url control\r\nminirank\r\nmiva\r\nmj12\r\nmnogosearch\r\nmoget\r\nmonster\r\nmoose\r\nmotor\r\nmultitext\r\nmuncher\r\nmuscatferret\r\nmwd.search\r\nmyweb\r\nnajdi\r\nnameprotect\r\nnationaldirectory\r\nnazilla\r\nncsa beta\r\nnec-meshexplorer\r\nnederland.zoek\r\nnetcarta webmap engine\r\nnetmechanic\r\nnetresearchserver\r\nnetscoop\r\nnewscan-online\r\nnhse\r\nnokia6682/\r\nnomad\r\nnoyona\r\nnutch\r\nnzexplorer\r\nobjectssearch\r\noccam\r\nomni\r\nopen text\r\nopenfind\r\nopenintelligencedata\r\norb search\r\nosis-project\r\npack rat\r\npageboy\r\npagebull\r\npage_verifier\r\npanscient\r\nparasite\r\npartnersite\r\npatric\r\npear.\r\npegasus\r\nperegrinator\r\npgp key agent\r\nphantom\r\nphpdig\r\npicosearch\r\npiltdownman\r\npimptrain\r\npinpoint\r\npioneer\r\npiranha\r\nplumtreewebaccessor\r\npogodak\r\npoirot\r\npompos\r\npoppelsdorf\r\npoppi\r\npopular iconoclast\r\npsycheclone\r\npublisher\r\npython\r\nrambler\r\nraven search\r\nroach\r\nroad runner\r\nroadhouse\r\nrobbie\r\nrobofox\r\nrobozilla\r\nrules\r\nsalty\r\nsbider\r\nscooter\r\nscoutjet\r\nscrubby\r\nsearch.\r\nsearchprocess\r\nsemanticdiscovery\r\nsenrigan\r\nsg-scout\r\nshai''hulud\r\nshark\r\nshopwiki\r\nsidewinder\r\nsift\r\nsilk\r\nsimmany\r\nsite searcher\r\nsite valet\r\nsitetech-rover\r\nskymob.com\r\nsleek\r\nsmartwit\r\nsna-\r\nsnappy\r\nsnooper\r\nsohu\r\nspeedfind\r\nsphere\r\nsphider\r\nspinner\r\nspyder\r\nsteeler/\r\nsuke\r\nsuntek\r\nsupersnooper\r\nsurfnomore\r\nsven\r\nsygol\r\nszukacz\r\ntach black widow\r\ntarantula\r\ntempleton\r\n/teoma\r\nt-h-u-n-d-e-r-s-t-o-n-e\r\ntheophrastus\r\ntitan\r\ntitin\r\ntkwww\r\ntoutatis\r\nt-rex\r\ntutorgig\r\ntwiceler\r\ntwisted\r\nucsd\r\nudmsearch\r\nurl check\r\nupdated\r\nvagabondo\r\nvalkyrie\r\nverticrawl\r\nvictoria\r\nvision-search\r\nvolcano\r\nvoyager/\r\nvoyager-hc\r\nw3c_validator\r\nw3m2\r\nw3mir\r\nwalker\r\nwallpaper\r\nwanderer\r\nwauuu\r\nwavefire\r\nweb core\r\nweb hopper\r\nweb wombat\r\nwebbandit\r\nwebcatcher\r\nwebcopy\r\nwebfoot\r\nweblayers\r\nweblinker\r\nweblog monitor\r\nwebmirror\r\nwebmonkey\r\nwebquest\r\nwebreaper\r\nwebsitepulse\r\nwebsnarf\r\nwebstolperer\r\nwebvac\r\nwebwalk\r\nwebwatch\r\nwebwombat\r\nwebzinger\r\nwhizbang\r\nwhowhere\r\nwild ferret\r\nworldlight\r\nwwwc\r\nwwwster\r\nxenu\r\nxget\r\nxift\r\nxirq\r\nyandex\r\nyanga\r\nyeti\r\nyodao\r\nzao\r\nzippp\r\nzyborg', 0),
(9924, 0, 'config', 'config_maintenance', '0', 0),
(9923, 0, 'config', 'config_mail_alert_email', '', 0),
(9922, 0, 'config', 'config_mail_alert', '["order"]', 1),
(9921, 0, 'config', 'config_mail_smtp_timeout', '5', 0),
(9920, 0, 'config', 'config_mail_smtp_port', '25', 0),
(9919, 0, 'config', 'config_mail_smtp_password', '', 0),
(9918, 0, 'config', 'config_mail_smtp_username', '', 0),
(9917, 0, 'config', 'config_mail_smtp_hostname', '', 0),
(9915, 0, 'config', 'config_mail_engine', 'mail', 0),
(9916, 0, 'config', 'config_mail_parameter', '', 0),
(9914, 0, 'config', 'config_icon', 'catalog/logo.png', 0),
(9912, 0, 'config', 'config_captcha_page', '["review","return","contact"]', 1),
(9913, 0, 'config', 'config_logo', 'catalog/logo.png', 0),
(8235, 0, 'payment_cod', 'payment_cod_sort_order', '', 0),
(8240, 0, 'payment_cheque', 'payment_cheque_payable', 'cash', 0),
(8241, 0, 'payment_cheque', 'payment_cheque_total', '1', 0),
(8242, 0, 'payment_cheque', 'payment_cheque_order_status_id', '7', 0),
(8243, 0, 'payment_cheque', 'payment_cheque_geo_zone_id', '0', 0),
(8244, 0, 'payment_cheque', 'payment_cheque_status', '1', 0),
(8245, 0, 'payment_cheque', 'payment_cheque_sort_order', '1', 0),
(9310, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_related_height', '304', 0),
(9309, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_related_width', '304', 0),
(9308, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_additional_height', '200', 0),
(9307, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_additional_width', '200', 0),
(9306, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_product_height', '304', 0),
(9305, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_product_width', '304', 0),
(9303, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_popup_width', '1000', 0),
(9304, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_popup_height', '1000', 0),
(9302, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_thumb_height', '800', 0),
(9300, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_category_height', '150', 0),
(9301, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_thumb_width', '800', 0),
(9299, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_category_width', '150', 0),
(9298, 0, 'theme_themeEZE765', 'theme_themeEZE765_simple_blog_share_social_site', '1', 0),
(9297, 0, 'theme_themeEZE765', 'theme_themeEZE765_simple_blog_related_articles', '1', 0),
(9296, 0, 'theme_themeEZE765', 'theme_themeEZE765_simple_blog_author_information', '1', 0),
(9294, 0, 'theme_themeEZE765', 'theme_themeEZE765_simple_blog_description_limit', '5', 0),
(9295, 0, 'theme_themeEZE765', 'theme_themeEZE765_simple_blog_comment_auto_approval', '1', 0),
(9293, 0, 'theme_themeEZE765', 'theme_themeEZE765_simple_blog_limit', '5', 0),
(9292, 0, 'theme_themeEZE765', 'theme_themeEZE765_simple_blog_status', '1', 0),
(9290, 0, 'theme_themeEZE765', 'theme_themeEZE765_product_limit', '9', 0),
(9291, 0, 'theme_themeEZE765', 'theme_themeEZE765_product_description_length', '210', 0),
(9289, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_quickview_height', '500', 0),
(9288, 0, 'theme_themeEZE765', 'theme_themeEZE765_image_quickview_width', '500', 0),
(9287, 0, 'theme_themeEZE765', 'theme_themeEZE765_product_zoom_type', '2', 0),
(9911, 0, 'config', 'config_captcha', '', 0),
(9910, 0, 'config', 'config_return_status_id', '2', 0),
(9909, 0, 'config', 'config_return_id', '0', 0),
(9908, 0, 'config', 'config_affiliate_id', '4', 0),
(9907, 0, 'config', 'config_affiliate_commission', '5', 0),
(9906, 0, 'config', 'config_affiliate_auto', '0', 0),
(9905, 0, 'config', 'config_affiliate_approval', '1', 0),
(9904, 0, 'config', 'config_affiliate_group_id', '1', 0),
(9903, 0, 'config', 'config_stock_checkout', '0', 0),
(9902, 0, 'config', 'config_stock_warning', '0', 0),
(9901, 0, 'config', 'config_stock_display', '0', 0),
(9900, 0, 'config', 'config_api_id', '6', 0),
(9899, 0, 'config', 'config_fraud_status_id', '7', 0),
(9898, 0, 'config', 'config_complete_status', '["5","3"]', 1),
(9897, 0, 'config', 'config_processing_status', '["5","1","2","12","3"]', 1),
(9896, 0, 'config', 'config_order_status_id', '1', 0),
(9895, 0, 'config', 'config_checkout_id', '5', 0),
(9894, 0, 'config', 'config_checkout_guest', '1', 0),
(9893, 0, 'config', 'config_cart_weight', '1', 0),
(9286, 0, 'theme_themeEZE765', 'theme_themeEZE765_label_new_limit', '10', 0),
(9285, 0, 'theme_themeEZE765', 'theme_themeEZE765_label_new', '1', 0),
(9284, 0, 'theme_themeEZE765', 'theme_themeEZE765_label_discount', '1', 0),
(9283, 0, 'theme_themeEZE765', 'theme_themeEZE765_label_sale', '1', 0),
(9282, 0, 'theme_themeEZE765', 'theme_themeEZE765_page_direction', 'ltr', 0),
(9281, 0, 'theme_themeEZE765', 'theme_themeEZE765_responsive', '0', 0),
(9280, 0, 'theme_themeEZE765', 'theme_themeEZE765_status', '1', 0),
(9279, 0, 'theme_themeEZE765', 'theme_themeEZE765_directory', 'themeEZE765', 0),
(9892, 0, 'config', 'config_invoice_prefix', 'INV-2020-00', 0),
(9872, 0, 'config', 'config_weight_class_id', '1', 0),
(9873, 0, 'config', 'config_special_counters', '1', 0),
(9874, 0, 'config', 'config_special_counters_title', '{"1":{"days_title":"days","hours_title":"hours","minutes_title":"min","seconds_title":"sec"},"2":{"days_title":"\\u0434","hours_title":"\\u0447","minutes_title":"\\u043c\\u0438\\u043d","seconds_title":"\\u0441\\u0435\\u043a"},"3":{"days_title":"\\u0623\\u064a\\u0627\\u0645","hours_title":"\\u0633\\u0627\\u0639\\u0627\\u062a","minutes_title":"\\u062f\\u0642\\u064a\\u0642\\u0629","seconds_title":"\\u062b\\u0648\\u0627\\u0646\\u064a"}}', 1),
(9891, 0, 'config', 'config_account_id', '3', 0),
(9890, 0, 'config', 'config_login_attempts', '5', 0),
(9889, 0, 'config', 'config_customer_price', '0', 0),
(9888, 0, 'config', 'config_customer_group_display', '["1"]', 1),
(9887, 0, 'config', 'config_customer_group_id', '1', 0),
(9886, 0, 'config', 'config_customer_search', '0', 0),
(9885, 0, 'config', 'config_customer_activity', '0', 0),
(9884, 0, 'config', 'config_customer_online', '0', 0),
(9883, 0, 'config', 'config_tax_customer', 'shipping', 0),
(9882, 0, 'config', 'config_tax_default', 'shipping', 0),
(9881, 0, 'config', 'config_tax', '0', 0),
(9880, 0, 'config', 'config_voucher_max', '1000', 0),
(9879, 0, 'config', 'config_voucher_min', '1', 0),
(9877, 0, 'config', 'config_review_status', '1', 0),
(9878, 0, 'config', 'config_review_guest', '1', 0),
(9875, 0, 'config', 'config_product_count', '1', 0),
(9876, 0, 'config', 'config_limit_admin', '20', 0),
(9871, 0, 'config', 'config_length_class_id', '1', 0),
(9870, 0, 'config', 'config_currency_auto', '1', 0),
(9869, 0, 'config', 'config_currency', 'USD', 0),
(9868, 0, 'config', 'config_admin_language', 'en-gb', 0),
(9867, 0, 'config', 'config_language', 'en-gb', 0),
(9866, 0, 'config', 'config_zone_id', '3563', 0),
(9865, 0, 'config', 'config_country_id', '222', 0),
(9864, 0, 'config', 'config_comment', 'We are glad to hear from you', 0),
(9863, 0, 'config', 'config_open', '7 Days a week from 9:00 am to 7:00 pm', 0),
(9862, 0, 'config', 'config_image', 'catalog/lookbook-col2.jpg', 0),
(9860, 0, 'config', 'config_telephone', '(800) 123-4567', 0),
(9861, 0, 'config', 'config_fax', '(800) 2345-6789', 0),
(9859, 0, 'config', 'config_email', 'admin@admin.com', 0),
(9858, 0, 'config', 'config_geocode', '40.6700, -73.9400', 0),
(9857, 0, 'config', 'config_address', 'My Company Glasgow D04 89GR', 0),
(9856, 0, 'config', 'config_owner', 'Zemez', 0),
(9855, 0, 'config', 'config_name', 'Foodleco', 0),
(9854, 0, 'config', 'config_layout_id', '4', 0),
(9853, 0, 'config', 'config_theme', 'themeEZE765', 0),
(9852, 0, 'config', 'config_meta_keyword', '', 0),
(9851, 0, 'config', 'config_meta_description', 'Foodleco', 0),
(9850, 0, 'config', 'config_meta_title', 'Foodleco', 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_article`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_article` (
  `simple_blog_article_id` int(16) NOT NULL,
  `simple_blog_author_id` int(16) NOT NULL,
  `allow_comment` tinyint(1) NOT NULL,
  `image` text NOT NULL,
  `featured_image` text NOT NULL,
  `article_related_method` varchar(64) NOT NULL,
  `article_related_option` text NOT NULL,
  `sort_order` int(8) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_simple_blog_article`
--

INSERT INTO `oc_simple_blog_article` (`simple_blog_article_id`, `simple_blog_author_id`, `allow_comment`, `image`, `featured_image`, `article_related_method`, `article_related_option`, `sort_order`, `status`, `date_added`, `date_modified`) VALUES
(1, 2, 1, '', 'catalog/blog/1.jpg', 'product_wise', '', 1, 1, '2020-02-20 11:28:47', '2020-07-15 16:12:33'),
(2, 1, 1, '', 'catalog/blog/2.jpg', 'product_wise', '', 2, 1, '2020-02-20 18:01:57', '2020-07-15 16:12:44'),
(3, 4, 1, '', 'catalog/blog/3.jpg', 'product_wise', '', 3, 1, '2020-02-25 14:56:26', '2020-07-15 16:12:51'),
(4, 4, 1, '', 'catalog/blog/4.jpg', 'product_wise', '', 0, 1, '2020-02-25 14:58:24', '2020-07-15 16:12:21');

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_article_description`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_article_description` (
  `simple_blog_article_description_id` int(16) NOT NULL,
  `simple_blog_article_id` int(16) NOT NULL,
  `language_id` int(16) NOT NULL,
  `article_title` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `meta_description` varchar(256) NOT NULL,
  `meta_keyword` varchar(256) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_simple_blog_article_description`
--

INSERT INTO `oc_simple_blog_article_description` (`simple_blog_article_description_id`, `simple_blog_article_id`, `language_id`, `article_title`, `description`, `meta_description`, `meta_keyword`) VALUES
(342, 1, 3, 'Establishing Your Brand on College Campuses', '&lt;p&gt;Many students are cash-strapped, nowadays. Nevertheless, their purchasing power is very high. Research reveals that 20 million students in the US have a combined disposable income of $417 billion. Moreover, another survey of students'' parents reveals that students now make 70 percent of their purchases themselves. These purchases are often made on credit cards. Therefore, students often have a significantly higher purchasing power.&lt;/p&gt;&lt;p&gt;If you know this, you can utilize it to capture the attention of the 16-24 age demographic. However, it is essential for your product or service to appeal to the lifestyle of the students. Additionally, student ambassadors should be utilized to spread the word about your product or service to their friends and classmates.&lt;/p&gt;&lt;p&gt;If you have not yet considered this demographic, it is time to reach out to them now! Social media is a popular method for socialization and communication between many young people. Students are the majority users of social networking sites like Facebook and Twitter. These are the right places to introduce brands to young people.It is probably the right place to introduce a brand to them. To capture the student audience, it is essential to be a part of the conversation; it is also important to keep them engaged. Social media is the ideal platform for this.&lt;/p&gt;&lt;p&gt;However, studies state that half of these social media savvy youngsters fail to follow brands on social networking sites. Students who do follow often only show temporary, marginal support. Social media is definitely a great platform for engaging students and spreading the word. However, it is definitely not the best for brand introduction and recognition.&lt;/p&gt;                                             ', '                                             ', ''),
(341, 1, 2, 'Establishing Your Brand on College Campuses', '&lt;p&gt;Many students are cash-strapped, nowadays. Nevertheless, their purchasing power is very high. Research reveals that 20 million students in the US have a combined disposable income of $417 billion. Moreover, another survey of students'' parents reveals that students now make 70 percent of their purchases themselves. These purchases are often made on credit cards. Therefore, students often have a significantly higher purchasing power.&lt;/p&gt;&lt;p&gt;If you know this, you can utilize it to capture the attention of the 16-24 age demographic. However, it is essential for your product or service to appeal to the lifestyle of the students. Additionally, student ambassadors should be utilized to spread the word about your product or service to their friends and classmates.&lt;/p&gt;&lt;p&gt;If you have not yet considered this demographic, it is time to reach out to them now! Social media is a popular method for socialization and communication between many young people. Students are the majority users of social networking sites like Facebook and Twitter. These are the right places to introduce brands to young people.It is probably the right place to introduce a brand to them. To capture the student audience, it is essential to be a part of the conversation; it is also important to keep them engaged. Social media is the ideal platform for this.&lt;/p&gt;&lt;p&gt;However, studies state that half of these social media savvy youngsters fail to follow brands on social networking sites. Students who do follow often only show temporary, marginal support. Social media is definitely a great platform for engaging students and spreading the word. However, it is definitely not the best for brand introduction and recognition.&lt;/p&gt;                                             ', '                                             ', ''),
(345, 2, 3, 'Believe in the Business of Your Dreams', ' &lt;p&gt;What is stopping you from believing in the business of your dreams? Insecurity? Fear? Lack of confidence? All of the above? How can you overcome these obstructions?&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Your Mantras&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;You may be wondering if you have the necessary skills, time, connections, and a million other things in order to create the business of your dreams. If you let your uncertainty and insecurity overpower you, you won''t ever be able to unleash your true business potential. To unlock the positive forces of your creativity and drive that will yield amazing results, make these your mantras:\r\n&quot;I will abandon all negative thoughts that prevent me from realizing my business objectives.&quot;\r\n&quot;I will focus my energy on growing the business of my dreams.&quot;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;A Dreamer and a Doer&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;It is important to take time to develop your vision; and your practical thinking should be geared to this vision. You need to work with conviction. Being a dreamer does not mean that you can''t also be a doer. In fact, having a dream is the starting point for building your dream business. The problem starts when you stop there instead of setting realizable immediate targets. Success cannot come from one day to the next. So you need to build your dream business bit by bit. When your dreams begin to be transformed into reality thanks to your actions, you become aware of the power you possess for catalyzing success; and this further strengthens your determination to reach every single one of your business goals.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Make It Happen&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Nothing can happen without tenacity, fortitude, and courage. Be bold enough to make choices; don''t just let things happen to you. Though you cannot have control over everything, you can focus on what you can handle and influence with your actions in a given situation. You have the power to make decisions that will move your business forward. You should not feel daunted by your lack of knowledge of business strategies either. You learn and grow while building your business. No women entrepreneur/mompreneur possesses absolute knowledge; there are so many examples of hugely successful businesswomen who started out without having any clue about business promotion techniques. Their motivation to learn, their unwavering belief that they could create the business of their dreams, and their steadfastness were key factors for their success.\r\n&lt;/p&gt;            ', '            ', ''),
(344, 2, 2, 'Believe in the Business of Your Dreams', ' &lt;p&gt;What is stopping you from believing in the business of your dreams? Insecurity? Fear? Lack of confidence? All of the above? How can you overcome these obstructions?&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Your Mantras&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;You may be wondering if you have the necessary skills, time, connections, and a million other things in order to create the business of your dreams. If you let your uncertainty and insecurity overpower you, you won''t ever be able to unleash your true business potential. To unlock the positive forces of your creativity and drive that will yield amazing results, make these your mantras:\r\n&quot;I will abandon all negative thoughts that prevent me from realizing my business objectives.&quot;\r\n&quot;I will focus my energy on growing the business of my dreams.&quot;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;A Dreamer and a Doer&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;It is important to take time to develop your vision; and your practical thinking should be geared to this vision. You need to work with conviction. Being a dreamer does not mean that you can''t also be a doer. In fact, having a dream is the starting point for building your dream business. The problem starts when you stop there instead of setting realizable immediate targets. Success cannot come from one day to the next. So you need to build your dream business bit by bit. When your dreams begin to be transformed into reality thanks to your actions, you become aware of the power you possess for catalyzing success; and this further strengthens your determination to reach every single one of your business goals.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Make It Happen&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Nothing can happen without tenacity, fortitude, and courage. Be bold enough to make choices; don''t just let things happen to you. Though you cannot have control over everything, you can focus on what you can handle and influence with your actions in a given situation. You have the power to make decisions that will move your business forward. You should not feel daunted by your lack of knowledge of business strategies either. You learn and grow while building your business. No women entrepreneur/mompreneur possesses absolute knowledge; there are so many examples of hugely successful businesswomen who started out without having any clue about business promotion techniques. Their motivation to learn, their unwavering belief that they could create the business of their dreams, and their steadfastness were key factors for their success.\r\n&lt;/p&gt;            ', '            ', ''),
(343, 2, 1, 'Believe in the Business of Your Dreams', ' &lt;p&gt;What is stopping you from believing in the business of your dreams? Insecurity? Fear? Lack of confidence? All of the above? How can you overcome these obstructions?&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Your Mantras&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;You may be wondering if you have the necessary skills, time, connections, and a million other things in order to create the business of your dreams. If you let your uncertainty and insecurity overpower you, you won''t ever be able to unleash your true business potential. To unlock the positive forces of your creativity and drive that will yield amazing results, make these your mantras:\r\n&quot;I will abandon all negative thoughts that prevent me from realizing my business objectives.&quot;\r\n&quot;I will focus my energy on growing the business of my dreams.&quot;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;A Dreamer and a Doer&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;It is important to take time to develop your vision; and your practical thinking should be geared to this vision. You need to work with conviction. Being a dreamer does not mean that you can''t also be a doer. In fact, having a dream is the starting point for building your dream business. The problem starts when you stop there instead of setting realizable immediate targets. Success cannot come from one day to the next. So you need to build your dream business bit by bit. When your dreams begin to be transformed into reality thanks to your actions, you become aware of the power you possess for catalyzing success; and this further strengthens your determination to reach every single one of your business goals.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Make It Happen&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Nothing can happen without tenacity, fortitude, and courage. Be bold enough to make choices; don''t just let things happen to you. Though you cannot have control over everything, you can focus on what you can handle and influence with your actions in a given situation. You have the power to make decisions that will move your business forward. You should not feel daunted by your lack of knowledge of business strategies either. You learn and grow while building your business. No women entrepreneur/mompreneur possesses absolute knowledge; there are so many examples of hugely successful businesswomen who started out without having any clue about business promotion techniques. Their motivation to learn, their unwavering belief that they could create the business of their dreams, and their steadfastness were key factors for their success.\r\n&lt;/p&gt;            ', '            ', ''),
(340, 1, 1, 'Establishing Your Brand on College Campuses', '&lt;p&gt;Many students are cash-strapped, nowadays. Nevertheless, their purchasing power is very high. Research reveals that 20 million students in the US have a combined disposable income of $417 billion. Moreover, another survey of students'' parents reveals that students now make 70 percent of their purchases themselves. These purchases are often made on credit cards. Therefore, students often have a significantly higher purchasing power.&lt;/p&gt;&lt;p&gt;If you know this, you can utilize it to capture the attention of the 16-24 age demographic. However, it is essential for your product or service to appeal to the lifestyle of the students. Additionally, student ambassadors should be utilized to spread the word about your product or service to their friends and classmates.&lt;/p&gt;&lt;p&gt;If you have not yet considered this demographic, it is time to reach out to them now! Social media is a popular method for socialization and communication between many young people. Students are the majority users of social networking sites like Facebook and Twitter. These are the right places to introduce brands to young people.It is probably the right place to introduce a brand to them. To capture the student audience, it is essential to be a part of the conversation; it is also important to keep them engaged. Social media is the ideal platform for this.&lt;/p&gt;&lt;p&gt;However, studies state that half of these social media savvy youngsters fail to follow brands on social networking sites. Students who do follow often only show temporary, marginal support. Social media is definitely a great platform for engaging students and spreading the word. However, it is definitely not the best for brand introduction and recognition.&lt;/p&gt;                                             ', '                                             ', ''),
(348, 3, 3, 'Impact - The Heart of Business', '  &lt;p&gt;Thousands of people dream of having their own business and even more so be a successful entrepreneur. But what does it take to achieve success in the business industry?&lt;/p&gt;\r\n\r\n&lt;p&gt;One of the most successful entrepreneurs featured at the Forbes website, Wendy Lipton - Dibner said that &quot;the success of your business would solely depend on you. The only thing you can rely on is your power to achieve your goal&quot;.\r\nShe shared her success story at the Forbes website and said that when she was young she learned a very important business objective from her high school activity and that is to go out, explore, come back and explain how money is made in business. This is an objective she never forgot until she made millions for herself.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;When she was already very successful, she never stopped understanding business and how it really works. Profit is the number one goal in business and how you make it is a natural talent. Yes, there may be a lot of guidelines given and showed on television and the internet but only you know how you will make your sales to the top.\r\n&lt;/p&gt;\r\n&lt;p&gt;Try to ponder on these notes when thinking of a business:\r\n&lt;/p&gt;\r\n\r\n&lt;ol&gt;\r\n&lt;li&gt;Passion. Business may be set on profit but the core of your business should be something you love. Passion counts a lot in businesses because it also builds your determination in achieving your goal.&lt;/li&gt;\r\n&lt;li&gt; Impact. Business is a big and competitive world, what will matter is how you make a difference to your market. How your business will impact your market. The profit of your business will rely on the impact of your business. The mark it will leave to your customers will make it grow.&lt;/li&gt;\r\n&lt;li&gt;Three Guidelines.&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;p&gt;If you have noticed, the three guidelines below are very simple and natural.&lt;/p&gt;          ', '          ', ''),
(347, 3, 2, 'Impact - The Heart of Business', '  &lt;p&gt;Thousands of people dream of having their own business and even more so be a successful entrepreneur. But what does it take to achieve success in the business industry?&lt;/p&gt;\r\n\r\n&lt;p&gt;One of the most successful entrepreneurs featured at the Forbes website, Wendy Lipton - Dibner said that &quot;the success of your business would solely depend on you. The only thing you can rely on is your power to achieve your goal&quot;.\r\nShe shared her success story at the Forbes website and said that when she was young she learned a very important business objective from her high school activity and that is to go out, explore, come back and explain how money is made in business. This is an objective she never forgot until she made millions for herself.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;When she was already very successful, she never stopped understanding business and how it really works. Profit is the number one goal in business and how you make it is a natural talent. Yes, there may be a lot of guidelines given and showed on television and the internet but only you know how you will make your sales to the top.\r\n&lt;/p&gt;\r\n&lt;p&gt;Try to ponder on these notes when thinking of a business:\r\n&lt;/p&gt;\r\n\r\n&lt;ol&gt;\r\n&lt;li&gt;Passion. Business may be set on profit but the core of your business should be something you love. Passion counts a lot in businesses because it also builds your determination in achieving your goal.&lt;/li&gt;\r\n&lt;li&gt; Impact. Business is a big and competitive world, what will matter is how you make a difference to your market. How your business will impact your market. The profit of your business will rely on the impact of your business. The mark it will leave to your customers will make it grow.&lt;/li&gt;\r\n&lt;li&gt;Three Guidelines.&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;p&gt;If you have noticed, the three guidelines below are very simple and natural.&lt;/p&gt;          ', '          ', ''),
(337, 4, 1, '5 Most Common Mistakes New Managers Make', ' &lt;p&gt;Learn which five most common mistakes a new manager is likely to make, and how to avoid them.&lt;/p&gt;\r\n\r\n    &lt;h5&gt;Mistake No.1 - Who''s the Boss?&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;Some of your subordinates will be young and new, eager to follow you. But, the experienced ones might be more\r\n       resistant to your directives. especially if it comes across as an order, disregarding their experience or\r\n       suggestions. Though, being the one with the responsibility, you also need to assert your authority, and make sure\r\n       your employees respect you and follow you.&lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;Your subordinates have a working style of their own, and it will not work well to dictate your ways on them. Stay\r\n       cool as long as they are committed to the work, compliance is another matter. Set targets and deadlines, but do\r\n       not interfere in their work, especially if they are long-standing employees in the company, even though you are\r\n       the one in the upper position.&lt;/p&gt;\r\n\r\n    &lt;h5&gt;Mistake No. 2 - I Want to Be the Cool Guy&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;While understanding your subordinates'' viewpoint and respecting their opinions is important, it is another thing\r\n       if you are letting them run the show or take it easy. It is you, after all, who will have to explain things when\r\n       the performance falls.&lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;Everyone hates to be the bad guy, that too, when you are new. But you have to find a balance between\r\n       micromanaging and giving no direction at all. Keep your mind open for suggestions, listen to everyone, but\r\n       ultimately you have to decide on the final direction your team/company takes. Also, do not excuse any slack\r\n       behavior. Tardiness or frequent leaves should not be taken lightly.&lt;/p&gt;\r\n\r\n\r\n    &lt;h5&gt;Mistake No. 3 - Setting Uniform, Inflexible Rules&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;If an employee is frequently late or absent, take him/her to task, but first, do understand the reasons behind\r\n       this issue. Some of them might be suffering from a health condition, or they might have a sick relative at home.\r\n       Same goes for other aspects of the job too.\r\n       While focusing on performance and target, it is easy to forget that you are dealing with people - not processes\r\n       or software which are programmed to run in a certain way. &lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;Understand that every employee is different, and will respond differently to authority or pressure. Rather than\r\n       take offense, it is best to find a way around.&lt;/p&gt;\r\n\r\n    &lt;h5&gt;Mistake No. 4 - Not Being Clear With Instructions&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;A few months? What exactly do you mean by few - is it two or six? As the planner, you might have a clear, precise\r\n       idea of what you want. But you also need to convey that to your subordinates. Being too vague can leave them\r\n       confused and lose trust in you.&lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;Make a clear, concise, and precise guideline. Give the employees fixed goals and targets. Numbers, not\r\n       approximates. They need to have a proper idea of how their performance will be measured, to stay motivated and\r\n       work efficiently and smartly.&lt;/p&gt;\r\n\r\n    &lt;h5&gt;Mistake No. 5 - Overestimating Yourself and Your Team&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;New managers are often eager and overenthusiastic. Free from the crutches of their B-school or the restrictions\r\n       of their previous job, they want to prove a lot. Brimming with new ideas, they just can''t wait to implement them\r\n       and the processes that they learned. They want to bring about a positive change, and fast.&lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;This enthusiasm is very infectious, affecting the entire team, resulting in a boost in productivity and morale.\r\n       But, unfortunately, it also means that the goals they set are also unrealistically high. Other employees may take\r\n       time adjusting to the sudden changes a new manager and his new processes demand. Add to that, they both will need\r\n       to be perfected and tweaked till you get the expected results. So, set realistic goals, and accept that the new\r\n       processes might also result in losses.&lt;/p&gt;                              ', '                              ', ''),
(339, 4, 3, '5 Most Common Mistakes New Managers Make', ' &lt;p&gt;Learn which five most common mistakes a new manager is likely to make, and how to avoid them.&lt;/p&gt;\r\n\r\n    &lt;h5&gt;Mistake No.1 - Who''s the Boss?&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;Some of your subordinates will be young and new, eager to follow you. But, the experienced ones might be more\r\n       resistant to your directives. especially if it comes across as an order, disregarding their experience or\r\n       suggestions. Though, being the one with the responsibility, you also need to assert your authority, and make sure\r\n       your employees respect you and follow you.&lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;Your subordinates have a working style of their own, and it will not work well to dictate your ways on them. Stay\r\n       cool as long as they are committed to the work, compliance is another matter. Set targets and deadlines, but do\r\n       not interfere in their work, especially if they are long-standing employees in the company, even though you are\r\n       the one in the upper position.&lt;/p&gt;\r\n\r\n    &lt;h5&gt;Mistake No. 2 - I Want to Be the Cool Guy&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;While understanding your subordinates'' viewpoint and respecting their opinions is important, it is another thing\r\n       if you are letting them run the show or take it easy. It is you, after all, who will have to explain things when\r\n       the performance falls.&lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;Everyone hates to be the bad guy, that too, when you are new. But you have to find a balance between\r\n       micromanaging and giving no direction at all. Keep your mind open for suggestions, listen to everyone, but\r\n       ultimately you have to decide on the final direction your team/company takes. Also, do not excuse any slack\r\n       behavior. Tardiness or frequent leaves should not be taken lightly.&lt;/p&gt;\r\n\r\n\r\n    &lt;h5&gt;Mistake No. 3 - Setting Uniform, Inflexible Rules&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;If an employee is frequently late or absent, take him/her to task, but first, do understand the reasons behind\r\n       this issue. Some of them might be suffering from a health condition, or they might have a sick relative at home.\r\n       Same goes for other aspects of the job too.\r\n       While focusing on performance and target, it is easy to forget that you are dealing with people - not processes\r\n       or software which are programmed to run in a certain way. &lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;Understand that every employee is different, and will respond differently to authority or pressure. Rather than\r\n       take offense, it is best to find a way around.&lt;/p&gt;\r\n\r\n    &lt;h5&gt;Mistake No. 4 - Not Being Clear With Instructions&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;A few months? What exactly do you mean by few - is it two or six? As the planner, you might have a clear, precise\r\n       idea of what you want. But you also need to convey that to your subordinates. Being too vague can leave them\r\n       confused and lose trust in you.&lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;Make a clear, concise, and precise guideline. Give the employees fixed goals and targets. Numbers, not\r\n       approximates. They need to have a proper idea of how their performance will be measured, to stay motivated and\r\n       work efficiently and smartly.&lt;/p&gt;\r\n\r\n    &lt;h5&gt;Mistake No. 5 - Overestimating Yourself and Your Team&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;New managers are often eager and overenthusiastic. Free from the crutches of their B-school or the restrictions\r\n       of their previous job, they want to prove a lot. Brimming with new ideas, they just can''t wait to implement them\r\n       and the processes that they learned. They want to bring about a positive change, and fast.&lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;This enthusiasm is very infectious, affecting the entire team, resulting in a boost in productivity and morale.\r\n       But, unfortunately, it also means that the goals they set are also unrealistically high. Other employees may take\r\n       time adjusting to the sudden changes a new manager and his new processes demand. Add to that, they both will need\r\n       to be perfected and tweaked till you get the expected results. So, set realistic goals, and accept that the new\r\n       processes might also result in losses.&lt;/p&gt;                              ', '                              ', ''),
(338, 4, 2, '5 Most Common Mistakes New Managers Make', ' &lt;p&gt;Learn which five most common mistakes a new manager is likely to make, and how to avoid them.&lt;/p&gt;\r\n\r\n    &lt;h5&gt;Mistake No.1 - Who''s the Boss?&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;Some of your subordinates will be young and new, eager to follow you. But, the experienced ones might be more\r\n       resistant to your directives. especially if it comes across as an order, disregarding their experience or\r\n       suggestions. Though, being the one with the responsibility, you also need to assert your authority, and make sure\r\n       your employees respect you and follow you.&lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;Your subordinates have a working style of their own, and it will not work well to dictate your ways on them. Stay\r\n       cool as long as they are committed to the work, compliance is another matter. Set targets and deadlines, but do\r\n       not interfere in their work, especially if they are long-standing employees in the company, even though you are\r\n       the one in the upper position.&lt;/p&gt;\r\n\r\n    &lt;h5&gt;Mistake No. 2 - I Want to Be the Cool Guy&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;While understanding your subordinates'' viewpoint and respecting their opinions is important, it is another thing\r\n       if you are letting them run the show or take it easy. It is you, after all, who will have to explain things when\r\n       the performance falls.&lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;Everyone hates to be the bad guy, that too, when you are new. But you have to find a balance between\r\n       micromanaging and giving no direction at all. Keep your mind open for suggestions, listen to everyone, but\r\n       ultimately you have to decide on the final direction your team/company takes. Also, do not excuse any slack\r\n       behavior. Tardiness or frequent leaves should not be taken lightly.&lt;/p&gt;\r\n\r\n\r\n    &lt;h5&gt;Mistake No. 3 - Setting Uniform, Inflexible Rules&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;If an employee is frequently late or absent, take him/her to task, but first, do understand the reasons behind\r\n       this issue. Some of them might be suffering from a health condition, or they might have a sick relative at home.\r\n       Same goes for other aspects of the job too.\r\n       While focusing on performance and target, it is easy to forget that you are dealing with people - not processes\r\n       or software which are programmed to run in a certain way. &lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;Understand that every employee is different, and will respond differently to authority or pressure. Rather than\r\n       take offense, it is best to find a way around.&lt;/p&gt;\r\n\r\n    &lt;h5&gt;Mistake No. 4 - Not Being Clear With Instructions&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;A few months? What exactly do you mean by few - is it two or six? As the planner, you might have a clear, precise\r\n       idea of what you want. But you also need to convey that to your subordinates. Being too vague can leave them\r\n       confused and lose trust in you.&lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;Make a clear, concise, and precise guideline. Give the employees fixed goals and targets. Numbers, not\r\n       approximates. They need to have a proper idea of how their performance will be measured, to stay motivated and\r\n       work efficiently and smartly.&lt;/p&gt;\r\n\r\n    &lt;h5&gt;Mistake No. 5 - Overestimating Yourself and Your Team&lt;/h5&gt;\r\n\r\n\r\n    &lt;p&gt;New managers are often eager and overenthusiastic. Free from the crutches of their B-school or the restrictions\r\n       of their previous job, they want to prove a lot. Brimming with new ideas, they just can''t wait to implement them\r\n       and the processes that they learned. They want to bring about a positive change, and fast.&lt;/p&gt;\r\n\r\n\r\n    &lt;p&gt;This enthusiasm is very infectious, affecting the entire team, resulting in a boost in productivity and morale.\r\n       But, unfortunately, it also means that the goals they set are also unrealistically high. Other employees may take\r\n       time adjusting to the sudden changes a new manager and his new processes demand. Add to that, they both will need\r\n       to be perfected and tweaked till you get the expected results. So, set realistic goals, and accept that the new\r\n       processes might also result in losses.&lt;/p&gt;                              ', '                              ', ''),
(346, 3, 1, 'Impact - The Heart of Business', ' &lt;p&gt;Thousands of people dream of having their own business and even more so be a successful entrepreneur. But what does it take to achieve success in the business industry?&lt;/p&gt;\r\n\r\n&lt;p&gt;One of the most successful entrepreneurs featured at the Forbes website, Wendy Lipton - Dibner said that &quot;the success of your business would solely depend on you. The only thing you can rely on is your power to achieve your goal&quot;.\r\nShe shared her success story at the Forbes website and said that when she was young she learned a very important business objective from her high school activity and that is to go out, explore, come back and explain how money is made in business. This is an objective she never forgot until she made millions for herself.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;When she was already very successful, she never stopped understanding business and how it really works. Profit is the number one goal in business and how you make it is a natural talent. Yes, there may be a lot of guidelines given and showed on television and the internet but only you know how you will make your sales to the top.\r\n&lt;/p&gt;\r\n&lt;p&gt;Try to ponder on these notes when thinking of a business:\r\n&lt;/p&gt;\r\n\r\n&lt;ol&gt;\r\n&lt;li&gt;Passion. Business may be set on profit but the core of your business should be something you love. Passion counts a lot in businesses because it also builds your determination in achieving your goal.&lt;/li&gt;\r\n&lt;li&gt; Impact. Business is a big and competitive world, what will matter is how you make a difference to your market. How your business will impact your market. The profit of your business will rely on the impact of your business. The mark it will leave to your customers will make it grow.&lt;/li&gt;\r\n&lt;li&gt;Three Guidelines.&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;p&gt;If you have noticed, the three guidelines below are very simple and natural.&lt;/p&gt;          ', '          ', '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_article_description_additional`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_article_description_additional` (
  `simple_blog_article_id` int(16) NOT NULL,
  `language_id` int(16) NOT NULL,
  `additional_description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_article_product_related`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_article_product_related` (
  `simple_blog_article_id` int(16) NOT NULL,
  `product_id` int(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_simple_blog_article_product_related`
--

INSERT INTO `oc_simple_blog_article_product_related` (`simple_blog_article_id`, `product_id`) VALUES
(3, 33),
(3, 34),
(2, 43),
(2, 33),
(1, 47),
(1, 33),
(1, 43),
(1, 42),
(4, 35),
(4, 40);

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_article_to_category`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_article_to_category` (
  `simple_blog_article_id` int(16) NOT NULL,
  `simple_blog_category_id` int(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_simple_blog_article_to_category`
--

INSERT INTO `oc_simple_blog_article_to_category` (`simple_blog_article_id`, `simple_blog_category_id`) VALUES
(1, 2),
(1, 3),
(2, 3),
(3, 3),
(3, 1),
(4, 2),
(4, 3);

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_article_to_layout`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_article_to_layout` (
  `simple_blog_article_id` int(16) NOT NULL,
  `store_id` int(16) NOT NULL,
  `layout_id` int(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_article_to_store`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_article_to_store` (
  `simple_blog_article_id` int(16) NOT NULL,
  `store_id` int(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_simple_blog_article_to_store`
--

INSERT INTO `oc_simple_blog_article_to_store` (`simple_blog_article_id`, `store_id`) VALUES
(1, 0),
(2, 0),
(3, 0),
(4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_author`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_author` (
  `simple_blog_author_id` int(16) NOT NULL,
  `name` varchar(256) NOT NULL,
  `image` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_simple_blog_author`
--

INSERT INTO `oc_simple_blog_author` (`simple_blog_author_id`, `name`, `image`, `status`, `date_added`, `date_modified`) VALUES
(1, 'Edna Barton', '', 1, '2020-02-20 11:20:22', '2020-02-20 11:20:22'),
(2, 'Jessica Prinston', '', 1, '2020-02-20 11:22:18', '2020-02-20 11:22:18'),
(3, 'Robert Johnson', '', 1, '2020-02-20 11:22:53', '2020-02-20 11:22:53'),
(4, 'Sam Kromstain', '', 1, '2020-02-20 11:23:29', '2020-02-20 11:23:29');

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_author_description`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_author_description` (
  `simple_blog_author_description_id` int(16) NOT NULL,
  `simple_blog_author_id` int(16) NOT NULL,
  `language_id` int(16) NOT NULL,
  `description` text NOT NULL,
  `meta_description` varchar(256) NOT NULL,
  `meta_keyword` varchar(256) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_simple_blog_author_description`
--

INSERT INTO `oc_simple_blog_author_description` (`simple_blog_author_description_id`, `simple_blog_author_id`, `language_id`, `description`, `meta_description`, `meta_keyword`, `date_added`) VALUES
(1, 1, 1, '&lt;p&gt;Quality control manager. Her mission is to check the products we ship and settle quality issues if any.&lt;br&gt;&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(2, 1, 2, '&lt;p&gt;Quality control manager. Her mission is to check the products we ship and settle quality issues if any.&lt;br&gt;&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(3, 1, 3, '&lt;p&gt;Quality control manager. Her mission is to check the products we ship and settle quality issues if any.&lt;br&gt;&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(4, 2, 1, '&lt;p&gt;Mega positive shop assistant always ready to help you make the right choice and charm you with a smile.&lt;br&gt;&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(5, 2, 2, '&lt;p&gt;Mega positive shop assistant always ready to help you make the right choice and charm you with a smile.&lt;br&gt;&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(6, 2, 3, '&lt;p&gt;Mega positive shop assistant always ready to help you make the right choice and charm you with a smile.&lt;br&gt;&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(7, 3, 1, '&lt;p&gt;Senior salesman with 15 years of experience. He knows everything about the products he offers.&lt;br&gt;&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(8, 3, 2, '&lt;p&gt;Senior salesman with 15 years of experience. He knows everything about the products he offers.&lt;br&gt;&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(9, 3, 3, '&lt;p&gt;Senior salesman with 15 years of experience. He knows everything about the products he offers.&lt;br&gt;&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(10, 4, 1, '&lt;p&gt;Wholesale manager. Contact him if you want to buy a batch of the products offered at our store.&lt;br&gt;&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(11, 4, 2, '&lt;p&gt;Wholesale manager. Contact him if you want to buy a batch of the products offered at our store.&lt;br&gt;&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(12, 4, 3, '&lt;p&gt;Wholesale manager. Contact him if you want to buy a batch of the products offered at our store.&lt;br&gt;&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_category`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_category` (
  `simple_blog_category_id` int(16) NOT NULL,
  `image` text NOT NULL,
  `parent_id` int(16) NOT NULL,
  `top` tinyint(1) NOT NULL,
  `blog_category_column` int(16) NOT NULL,
  `column` int(8) NOT NULL,
  `sort_order` int(8) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_simple_blog_category`
--

INSERT INTO `oc_simple_blog_category` (`simple_blog_category_id`, `image`, `parent_id`, `top`, `blog_category_column`, `column`, `sort_order`, `status`, `date_added`, `date_modified`) VALUES
(1, '', 0, 0, 0, 5, 0, 1, '2020-02-20 11:25:07', '2020-02-20 11:25:07'),
(2, '', 0, 0, 0, 5, 0, 1, '2020-02-20 11:25:45', '2020-02-20 11:25:45'),
(3, '', 0, 0, 0, 5, 0, 1, '2020-02-20 11:26:24', '2020-02-20 11:26:24');

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_category_description`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_category_description` (
  `simple_blog_category_description_id` int(16) NOT NULL,
  `simple_blog_category_id` int(16) NOT NULL,
  `language_id` int(16) NOT NULL,
  `name` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `meta_description` varchar(256) NOT NULL,
  `meta_keyword` varchar(256) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_simple_blog_category_description`
--

INSERT INTO `oc_simple_blog_category_description` (`simple_blog_category_description_id`, `simple_blog_category_id`, `language_id`, `name`, `description`, `meta_description`, `meta_keyword`) VALUES
(1, 1, 1, ' Branding ', '', ' ', ''),
(2, 1, 2, ' Branding ', '', ' ', ''),
(3, 1, 3, ' Branding ', '', ' ', ''),
(4, 2, 1, ' Management ', '', ' ', ''),
(5, 2, 2, ' Management ', '', ' ', ''),
(6, 2, 3, ' Management ', '', ' ', ''),
(7, 3, 1, ' Customer Service ', '', ' ', ''),
(8, 3, 2, ' Customer Service ', '', ' ', ''),
(9, 3, 3, ' Customer Service ', '', ' ', '');

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_category_to_layout`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_category_to_layout` (
  `simple_blog_category_id` int(16) NOT NULL,
  `store_id` int(16) NOT NULL,
  `layout_id` int(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_category_to_store`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_category_to_store` (
  `simple_blog_category_id` int(16) NOT NULL,
  `store_id` int(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_simple_blog_category_to_store`
--

INSERT INTO `oc_simple_blog_category_to_store` (`simple_blog_category_id`, `store_id`) VALUES
(1, 0),
(2, 0),
(3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_comment`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_comment` (
  `simple_blog_comment_id` int(16) NOT NULL,
  `simple_blog_article_id` int(16) NOT NULL,
  `simple_blog_article_reply_id` int(16) NOT NULL,
  `author` varchar(64) NOT NULL,
  `comment` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_related_article`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_related_article` (
  `simple_blog_related_article_id` int(16) NOT NULL,
  `simple_blog_article_id` int(16) NOT NULL,
  `simple_blog_article_related_id` int(16) NOT NULL,
  `sort_order` int(8) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_simple_blog_related_article`
--

INSERT INTO `oc_simple_blog_related_article` (`simple_blog_related_article_id`, `simple_blog_article_id`, `simple_blog_article_related_id`, `sort_order`, `status`, `date_added`) VALUES
(141, 1, 3, 2, 1, '2020-07-15 16:12:33'),
(143, 2, 3, 0, 1, '2020-07-15 16:12:44'),
(142, 2, 1, 1, 1, '2020-07-15 16:12:44'),
(145, 3, 4, 2, 1, '2020-07-15 16:12:51'),
(144, 3, 2, 1, 1, '2020-07-15 16:12:51'),
(139, 4, 1, 3, 1, '2020-07-15 16:12:21'),
(138, 4, 2, 1, 1, '2020-07-15 16:12:21'),
(140, 1, 2, 0, 1, '2020-07-15 16:12:33');

-- --------------------------------------------------------

--
-- Table structure for table `oc_simple_blog_view`
--

CREATE TABLE IF NOT EXISTS `oc_simple_blog_view` (
  `simple_blog_view_id` int(16) NOT NULL,
  `simple_blog_article_id` int(16) NOT NULL,
  `view` int(16) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oc_simple_blog_view`
--

INSERT INTO `oc_simple_blog_view` (`simple_blog_view_id`, `simple_blog_article_id`, `view`, `date_added`, `date_modified`) VALUES
(1, 1, 120, '2020-02-20 11:29:32', '2020-03-31 08:22:22'),
(2, 2, 154, '2020-02-24 14:46:11', '2020-04-14 12:16:09'),
(3, 3, 64, '2020-02-25 15:06:41', '2020-07-15 16:44:16'),
(4, 4, 81, '2020-02-29 11:50:35', '2020-04-20 17:38:50');

-- --------------------------------------------------------

--
-- Table structure for table `oc_zemez_newsletter`
--

CREATE TABLE IF NOT EXISTS `oc_zemez_newsletter` (
  `zemez_newsletter_id` int(11) NOT NULL,
  `zemez_newsletter_email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `oc_banner`
--
ALTER TABLE `oc_banner`
  ADD PRIMARY KEY (`banner_id`);

--
-- Indexes for table `oc_banner_image`
--
ALTER TABLE `oc_banner_image`
  ADD PRIMARY KEY (`banner_image_id`);

--
-- Indexes for table `oc_layout`
--
ALTER TABLE `oc_layout`
  ADD PRIMARY KEY (`layout_id`);

--
-- Indexes for table `oc_layout_module`
--
ALTER TABLE `oc_layout_module`
  ADD PRIMARY KEY (`layout_module_id`);

--
-- Indexes for table `oc_layout_route`
--
ALTER TABLE `oc_layout_route`
  ADD PRIMARY KEY (`layout_route_id`);

--
-- Indexes for table `oc_module`
--
ALTER TABLE `oc_module`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `oc_setting`
--
ALTER TABLE `oc_setting`
  ADD PRIMARY KEY (`setting_id`);

--
-- Indexes for table `oc_simple_blog_article`
--
ALTER TABLE `oc_simple_blog_article`
  ADD PRIMARY KEY (`simple_blog_article_id`);

--
-- Indexes for table `oc_simple_blog_article_description`
--
ALTER TABLE `oc_simple_blog_article_description`
  ADD PRIMARY KEY (`simple_blog_article_description_id`);

--
-- Indexes for table `oc_simple_blog_author`
--
ALTER TABLE `oc_simple_blog_author`
  ADD PRIMARY KEY (`simple_blog_author_id`);

--
-- Indexes for table `oc_simple_blog_author_description`
--
ALTER TABLE `oc_simple_blog_author_description`
  ADD PRIMARY KEY (`simple_blog_author_description_id`);

--
-- Indexes for table `oc_simple_blog_category`
--
ALTER TABLE `oc_simple_blog_category`
  ADD PRIMARY KEY (`simple_blog_category_id`);

--
-- Indexes for table `oc_simple_blog_category_description`
--
ALTER TABLE `oc_simple_blog_category_description`
  ADD PRIMARY KEY (`simple_blog_category_description_id`);

--
-- Indexes for table `oc_simple_blog_comment`
--
ALTER TABLE `oc_simple_blog_comment`
  ADD PRIMARY KEY (`simple_blog_comment_id`);

--
-- Indexes for table `oc_simple_blog_related_article`
--
ALTER TABLE `oc_simple_blog_related_article`
  ADD PRIMARY KEY (`simple_blog_related_article_id`);

--
-- Indexes for table `oc_simple_blog_view`
--
ALTER TABLE `oc_simple_blog_view`
  ADD PRIMARY KEY (`simple_blog_view_id`);

--
-- Indexes for table `oc_zemez_newsletter`
--
ALTER TABLE `oc_zemez_newsletter`
  ADD PRIMARY KEY (`zemez_newsletter_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `oc_banner`
--
ALTER TABLE `oc_banner`
  MODIFY `banner_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_banner_image`
--
ALTER TABLE `oc_banner_image`
  MODIFY `banner_image_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_layout`
--
ALTER TABLE `oc_layout`
  MODIFY `layout_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_layout_module`
--
ALTER TABLE `oc_layout_module`
  MODIFY `layout_module_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_layout_route`
--
ALTER TABLE `oc_layout_route`
  MODIFY `layout_route_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_module`
--
ALTER TABLE `oc_module`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_setting`
--
ALTER TABLE `oc_setting`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_simple_blog_article`
--
ALTER TABLE `oc_simple_blog_article`
  MODIFY `simple_blog_article_id` int(16) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_simple_blog_article_description`
--
ALTER TABLE `oc_simple_blog_article_description`
  MODIFY `simple_blog_article_description_id` int(16) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_simple_blog_author`
--
ALTER TABLE `oc_simple_blog_author`
  MODIFY `simple_blog_author_id` int(16) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_simple_blog_author_description`
--
ALTER TABLE `oc_simple_blog_author_description`
  MODIFY `simple_blog_author_description_id` int(16) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_simple_blog_category`
--
ALTER TABLE `oc_simple_blog_category`
  MODIFY `simple_blog_category_id` int(16) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_simple_blog_category_description`
--
ALTER TABLE `oc_simple_blog_category_description`
  MODIFY `simple_blog_category_description_id` int(16) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_simple_blog_comment`
--
ALTER TABLE `oc_simple_blog_comment`
  MODIFY `simple_blog_comment_id` int(16) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_simple_blog_related_article`
--
ALTER TABLE `oc_simple_blog_related_article`
  MODIFY `simple_blog_related_article_id` int(16) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_simple_blog_view`
--
ALTER TABLE `oc_simple_blog_view`
  MODIFY `simple_blog_view_id` int(16) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_zemez_newsletter`
--
ALTER TABLE `oc_zemez_newsletter`
  MODIFY `zemez_newsletter_id` int(11) NOT NULL AUTO_INCREMENT;

