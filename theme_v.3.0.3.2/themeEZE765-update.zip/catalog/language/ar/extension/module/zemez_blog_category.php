<?php
// Heading 
$_['heading_title']       = 'بلوق الفئة';

// Text
$_['text_search_article'] = 'بحث المادة';

// Buttons
$_['button_search']       = 'بحث';

?>