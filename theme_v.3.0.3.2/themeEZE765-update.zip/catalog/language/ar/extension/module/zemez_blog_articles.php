<?php

// Heading 
$_['heading_title']        = 'مدونة';

$_['text_date_format']     = 'd.m.y';

$_['text_popular_all']     = 'المواد شعبية';
$_['text_latest_all']      = 'أحدث المقالات';
$_['text_button_continue'] = 'اقرأ أكثر';
$_['text_comments']        = ' تعليقات';
$_['text_comment']         = 'التعليق';
$_['text_all_blog']       = 'عرض جميع بلوق';


$_['text_no_result']       = 'لا نتيجة!';

?>