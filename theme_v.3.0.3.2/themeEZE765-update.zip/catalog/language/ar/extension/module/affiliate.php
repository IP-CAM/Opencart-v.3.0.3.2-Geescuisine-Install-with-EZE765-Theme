<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'نظام العمولة';

// Text
$_['text_register']    = 'تسجيل';
$_['text_login']       = 'دخول';
$_['text_logout']      = 'خروج';
$_['text_forgotten']   = 'نسيت كلمة المرور';
$_['text_account']     = 'حسابي';
$_['text_edit']        = 'تحرير الحساب';
$_['text_password']    = 'كلمة المرور';
$_['text_payment']     = 'خيارات الدفع';
$_['text_tracking']    = 'تتبع نظام العمولة';
$_['text_transaction'] = 'رصيدي';
