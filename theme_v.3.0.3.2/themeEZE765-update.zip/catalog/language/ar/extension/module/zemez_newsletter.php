<?php
// Heading
$_['heading_title']       = 'النشرة الإخبارية';

// Entry
$_['entry_mail']          = 'ادخل بريدك الإلكتروني';

// Text
$_['button_subscribe']    = 'الاشتراك';
$_['text_success']        = 'لقد اشتركت بنجاح';

//Errors
$_['error_exist_user']    = 'مسجل بالفعل';
$_['error_exist_email']   = 'البريد الإلكتروني المحدد مشترك بالفعل';
$_['error_invalid_email'] = 'يرجى إدخال البريد الإلكتروني الصحيح!';