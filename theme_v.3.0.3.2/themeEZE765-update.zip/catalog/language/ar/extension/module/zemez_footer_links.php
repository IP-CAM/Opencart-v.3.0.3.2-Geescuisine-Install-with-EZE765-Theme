<?php
// Text
$_['text_telephone']    = 'هاتف';
$_['text_fax']          = 'الفاكس';
$_['text_email']        = 'البريد الإلكتروني:';
$_['text_catalog']      = 'المنتجات كتالوج';
$_['text_contacts']      = 'ردود الفعل';
$_['text_lookbook']     = 'انظر كتاب';
$_['text_simple_blog']  = 'مدونة';
$_['text_more']         = 'المزيد من الطرق للتسوق';
$_['text_store']        = 'ابحث عن متجر';
$_['text_gift_cards']   = 'بطاقات الهدايا';
$_['text_wishlist']     = 'العثور على قائمة الامنيات';
$_['text_information']  = 'معلومات';
$_['text_service']      = 'خدمات العملاء';
$_['text_extra']        = 'إضافات';
$_['text_contact']      = 'اتصل بنا';
$_['text_return']       = 'إرجاع الطلب';
$_['text_sitemap']      = 'خريطة الموقع';
$_['text_manufacturer'] = 'الشركات';
$_['text_voucher']      = 'قسائم الهدايا';
$_['text_affiliate']    = 'نظام العمولة';
$_['text_special']      = 'العروض المميزة';
$_['text_account']      = 'حسابي';
$_['text_order']        = 'طلباتي';
$_['text_wishlist']     = 'قائمة رغباتي';
$_['text_newsletter']   = 'القائمة البريدية';
$_['text_powered']      = 'ترجمة <a href="http://www.opencartarab.com" target="_blank">OpenCartArab</a> | دعـم <a href="http://www.opencart.com" target="_blank">OpenCart</a> %s &copy; %s';