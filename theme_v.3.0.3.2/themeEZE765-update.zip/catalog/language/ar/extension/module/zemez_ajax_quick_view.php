<?php
// Text

$_['text_manufacturer'] = 'العلامة التجارية:';
$_['text_model']        = 'نموذج:';
$_['text_new']          = 'جديد';
$_['text_option']       = 'الخيارات المتوفرة';
$_['text_quick']        = 'نظرة سريعة';
$_['text_sale']         = 'تخفيض السعر';
$_['text_select']       = '--- اختر من فضلك ---';
$_['text_tax']          = 'الضرائب السابقين:';
$_['entry_qty']         = 'كمية';
