<?php
// Heading
$_['heading_facebook_title']    = 'Facebook';

// Text
$_['text_edit']        = 'Редактировать аккаунт';
