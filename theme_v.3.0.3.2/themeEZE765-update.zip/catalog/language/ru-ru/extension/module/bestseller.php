<?php
// Heading
$_['heading_title'] = 'Хит продаж';

// Text
$_['text_tax']      = 'Без НДС:';

