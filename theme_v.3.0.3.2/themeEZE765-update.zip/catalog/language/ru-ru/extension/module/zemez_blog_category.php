<?php
// Heading 
$_['heading_title']       = 'Категории блога';

// Text
$_['text_search_article'] = 'Поиск статьи';

// Buttons
$_['button_search']       = 'Поиск';

?>