<?php
// Text
$_['text_search'] = 'Поиск';
