<?php
// Text

$_['text_sale']          = 'Sale';
$_['text_new']           = 'New';
$_['text_select']        = '--- Please Select ---';
$_['text_tax']           = 'Ex Tax:';
// Button
$_['button_collections'] = 'View All Collections';