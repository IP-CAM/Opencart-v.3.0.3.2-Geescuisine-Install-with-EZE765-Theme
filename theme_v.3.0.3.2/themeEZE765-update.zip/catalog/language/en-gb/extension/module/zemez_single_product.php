<?php
// Heading
$_['zemez_heading_title'] = 'Zemez Single Product products';
// Text
$_['text_tax'] = 'Ex Tax:';
$_['text_sale'] = 'Sale';
$_['text_brand'] = 'Brand';
$_['text_manufacturer'] = 'Brand:';
$_['text_model'] = 'Product Code:';
$_['text_reward'] = 'Reward Points:';
$_['text_points'] = 'Price in reward points:';
$_['text_stock'] = 'Availability:';
$_['text_instock'] = 'In Stock';
$_['text_quantity'] = 'Qty:';
$_['text_category'] = 'Categories';
$_['text_manufacturer'] = 'Brand:';
$_['text_model'] = 'Model:';
$_['text_availability'] = 'Availability:';
$_['text_outstock'] = 'Out Stock';
$_['text_price'] = 'Price: ';
$_['text_quick'] = 'Quick View';
$_['button_details'] = 'Details';
$_['reviews'] = 'reviews ';
$_['text_product'] = 'Product {current} of {total} ';
$_['text_option'] = 'Available Options';
$_['text_select'] = '--- Please Select ---';